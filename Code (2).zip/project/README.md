# Password Cracking & Encryption Demo

A Python-based educational tool demonstrating password security concepts, hashing algorithms, and attack methods.

## Overview

This project provides a comprehensive simulation of password security mechanisms and attack vectors for educational purposes. It demonstrates:

- Different password hashing algorithms and their properties
- The importance of salting passwords
- Brute force attack simulation
- Dictionary attack simulation
- Password strength analysis
- Performance comparison of hashing algorithms

## Key Concepts Explained

### Hashing vs. Encryption vs. Salting

#### Hashing

Hashing is a one-way function that converts input data (like a password) into a fixed-length string of characters. Key characteristics:

- One-way process (cannot be reversed)
- Same input always produces the same output
- Even small changes in input produce completely different outputs
- Fixed output length regardless of input size

**Examples:** MD5, SHA-256, bcrypt, PBKDF2

#### Encryption

Encryption is a two-way function that converts data into a different format using a key. Key characteristics:

- Can be reversed (decrypted) with the correct key
- Designed to protect data that needs to be retrieved later
- Uses mathematical algorithms to transform data

**Examples:** AES, RSA, DES

#### Salting

Salting is a technique where random data (a "salt") is added to the input before hashing. Key benefits:

- Prevents rainbow table attacks
- Ensures that identical passwords don't result in identical hashes
- Significantly increases security when used with proper hashing algorithms

### Why Passwords Should Be Hashed, Not Encrypted

Passwords should be hashed rather than encrypted because:

1. **No Need to Retrieve:** There's never a legitimate reason to recover a user's original password
2. **Security:** If encrypted passwords are compromised, they can be decrypted with the key
3. **Authentication:** Authentication only requires verification, not retrieval

### Modern Password Hashing Best Practices

1. **Use Specialized Algorithms:** Use algorithms specifically designed for password hashing (bcrypt, Argon2, PBKDF2)
2. **Always Salt:** Always use unique salts for each password
3. **Work Factor:** Use adjustable work factors to make hashing computationally expensive
4. **Keep Current:** Stay updated on security recommendations as computing power increases

## Common Attack Methods

### Brute Force Attacks

A brute force attack tries every possible character combination until finding the correct password. This project demonstrates:

- How brute force attacks work
- Why longer passwords are exponentially more secure
- How modern hashing algorithms slow down brute force attacks

### Dictionary Attacks

Dictionary attacks use lists of common passwords and words instead of trying all combinations. This project shows:

- Basic dictionary attack implementation
- Enhanced attacks with common password transformations
- Why unique, non-dictionary passwords are important

### Rainbow Table Attacks

While not directly implemented, the project explains how rainbow tables (precomputed hash tables) work and why proper salting defeats this attack.

## Installation

```bash
# Clone the repository
git clone https://github.com/username/password-security-demo.git
cd password-security-demo

# Install dependencies
pip install -r requirements.txt
```

## Usage

### Interactive Demo

```bash
python src/main.py demo
```

### Hash a Password

```bash
python src/main.py hash "your_password" --algorithm bcrypt
```

### Analyze Password Strength

```bash
python src/main.py analyze "your_password"
```

### Simulate an Attack

```bash
# Dictionary attack on a SHA-256 hash
python src/main.py attack "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8" --type dictionary --algorithm sha256

# Brute force attack
python src/main.py attack "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8" --type brute-force --min-length 1 --max-length 6
```

## Educational Resources

This project is designed for educational purposes to help understand:

- How password security mechanisms work
- Why certain practices (like salting and using specialized algorithms) are important
- The limitations of different hashing algorithms
- The effectiveness of different attack methods

## Disclaimer

This tool is created for educational purposes only. It demonstrates security concepts that should be used responsibly and ethically. Do not use these techniques to attempt unauthorized access to any systems.

## License

MIT License - See LICENSE file for details.