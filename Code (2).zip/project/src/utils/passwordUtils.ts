// Common password list for demonstration
export const getCommonPasswords = (): string[] => {
  return [
    "password", "123456", "12345678", "qwerty", "abc123", 
    "monkey", "1234567", "letmein", "trustno1", "dragon", 
    "baseball", "111111", "iloveyou", "master", "sunshine", 
    "ashley", "bailey", "passw0rd", "shadow", "123123", 
    "654321", "superman", "qazwsx", "michael", "football",
    "welcome", "jesus", "ninja", "mustang", "password1",
    "admin", "solo", "access", "flower", "donald",
    "killer", "freedom", "whatever", "jordan", "jennifer",
    "hunter", "rangers", "batman", "soccer", "thomas",
    "summer", "corvette", "matrix", "computer", "starwars"
  ];
};

// Apply common transformations to a password
export const applyCommonTransformations = (password: string): string[] => {
  const variations: string[] = [];
  
  // Original password
  variations.push(password);
  
  // Capitalized
  variations.push(password.charAt(0).toUpperCase() + password.slice(1));
  
  // All uppercase
  variations.push(password.toUpperCase());
  
  // Add common number suffixes
  for (let i = 0; i < 10; i++) {
    variations.push(`${password}${i}`);
  }
  
  variations.push(`${password}123`);
  variations.push(`${password}1234`);
  
  // Common character replacements
  const replacements: Record<string, string> = {
    'a': '@',
    'e': '3',
    'i': '1',
    'o': '0',
    's': '$'
  };
  
  let replaced = password;
  for (const [char, replacement] of Object.entries(replacements)) {
    if (password.includes(char)) {
      replaced = replaced.replace(new RegExp(char, 'g'), replacement);
    }
  }
  
  if (replaced !== password) {
    variations.push(replaced);
  }
  
  return variations;
};

// Check for common patterns in a password
export const checkCommonPatterns = (password: string): string[] => {
  const patterns: string[] = [];
  
  // Check for sequential characters
  const sequences = [
    'abcdefghijklmnopqrstuvwxyz',
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    '0123456789',
    'qwertyuiop',
    'asdfghjkl',
    'zxcvbnm'
  ];
  
  for (const seq of sequences) {
    for (let i = 0; i < seq.length - 2; i++) {
      const fragment = seq.substring(i, i + 3);
      if (password.includes(fragment)) {
        patterns.push(`Sequential characters: ${fragment}`);
        break;
      }
    }
  }
  
  // Check for repeated characters
  for (let i = 0; i < password.length - 2; i++) {
    if (password[i] === password[i + 1] && password[i] === password[i + 2]) {
      patterns.push(`Repeated characters: ${password[i].repeat(3)}`);
      break;
    }
  }
  
  // Check for common years
  if (password.match(/19\d\d|20\d\d/)) {
    patterns.push("Contains a year");
  }
  
  // Check for keyboard patterns
  const keyboardPatterns = [
    'qwerty', 'asdfgh', 'zxcvbn', '123456', 'qazwsx'
  ];
  
  for (const pattern of keyboardPatterns) {
    if (password.toLowerCase().includes(pattern)) {
      patterns.push(`Keyboard pattern: ${pattern}`);
      break;
    }
  }
  
  return patterns;
};

// Calculate the entropy of a password
export const calculateEntropy = (password: string): number => {
  // Determine character sets used
  const hasLower = /[a-z]/.test(password);
  const hasUpper = /[A-Z]/.test(password);
  const hasDigit = /\d/.test(password);
  const hasSymbol = /[^a-zA-Z0-9]/.test(password);
  
  // Calculate the size of the character set
  let charsetSize = 0;
  if (hasLower) charsetSize += 26;
  if (hasUpper) charsetSize += 26;
  if (hasDigit) charsetSize += 10;
  if (hasSymbol) charsetSize += 33; // Approximate number of common symbols
  
  // Empty password
  if (charsetSize === 0) return 0;
  
  // Calculate entropy (log2(charset_size) * password_length)
  return Math.log2(charsetSize) * password.length;
};

// Analyze the strength of a password
export const analyzePasswordStrength = (password: string) => {
  // Calculate basic metrics
  const length = password.length;
  const entropy = calculateEntropy(password);
  const patterns = checkCommonPatterns(password);
  
  // Character composition
  const charComposition = {
    lowercase: (password.match(/[a-z]/g) || []).length,
    uppercase: (password.match(/[A-Z]/g) || []).length,
    digits: (password.match(/\d/g) || []).length,
    symbols: (password.match(/[^a-zA-Z0-9]/g) || []).length
  };
  
  // Determine strength category
  let strength;
  let crackTimeEstimate;
  
  if (entropy < 28) {
    strength = "Very Weak";
    crackTimeEstimate = "Instant to a few seconds";
  } else if (entropy < 36) {
    strength = "Weak";
    crackTimeEstimate = "Minutes to hours";
  } else if (entropy < 60) {
    strength = "Moderate";
    crackTimeEstimate = "Days to weeks";
  } else if (entropy < 80) {
    strength = "Strong";
    crackTimeEstimate = "Years to decades";
  } else {
    strength = "Very Strong";
    crackTimeEstimate = "Centuries or more";
  }
  
  // Adjust strength based on patterns
  if (patterns.length > 0 && entropy < 70) {
    // Decrease strength if patterns are found
    if (strength === "Very Strong") {
      strength = "Strong";
    } else if (strength === "Strong") {
      strength = "Moderate";
    } else if (strength === "Moderate") {
      strength = "Weak";
    } else if (strength === "Weak") {
      strength = "Very Weak";
    }
    
    // Adjust crack time estimate
    if (crackTimeEstimate === "Centuries or more") {
      crackTimeEstimate = "Years to decades";
    } else if (crackTimeEstimate === "Years to decades") {
      crackTimeEstimate = "Weeks to months";
    } else if (crackTimeEstimate === "Days to weeks") {
      crackTimeEstimate = "Hours to days";
    } else if (crackTimeEstimate === "Minutes to hours") {
      crackTimeEstimate = "Seconds to minutes";
    }
  }
  
  // Improvement suggestions
  const suggestions = [];
  
  if (length < 12) {
    suggestions.push("Make your password longer (at least 12 characters)");
  }
  if (charComposition.lowercase === 0) {
    suggestions.push("Add lowercase letters");
  }
  if (charComposition.uppercase === 0) {
    suggestions.push("Add uppercase letters");
  }
  if (charComposition.digits === 0) {
    suggestions.push("Add numbers");
  }
  if (charComposition.symbols === 0) {
    suggestions.push("Add special characters");
  }
  if (patterns.length > 0) {
    suggestions.push("Avoid common patterns and sequences");
  }
  
  return {
    length,
    entropy,
    strength,
    character_composition: charComposition,
    patterns_found: patterns,
    estimated_crack_time: crackTimeEstimate,
    improvement_suggestions: suggestions
  };
};