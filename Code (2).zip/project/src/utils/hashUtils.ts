import CryptoJS from 'crypto-js';
import bcrypt from 'bcryptjs';

// Generate a hash for a password using various algorithms
export const generateHash = async (
  password: string,
  type: string,
  options: any = {}
) => {
  switch (type) {
    case 'plain':
      return {
        hash: password,
      };
    
    case 'md5':
      return {
        hash: CryptoJS.MD5(password).toString(),
      };
    
    case 'sha256':
      return {
        hash: CryptoJS.SHA256(password).toString(),
      };
    
    case 'sha256-salted': {
      // Generate a random salt if not provided
      const salt = options.salt || CryptoJS.lib.WordArray.random(32).toString();
      
      // Hash the password with the salt
      const hash = CryptoJS.SHA256(salt + password).toString();
      
      return {
        hash,
        salt,
      };
    }
    
    case 'bcrypt': {
      const rounds = options.rounds || 10;
      const hash = await bcrypt.hash(password, rounds);
      
      return {
        hash,
      };
    }
    
    case 'pbkdf2': {
      const salt = options.salt || CryptoJS.lib.WordArray.random(16).toString();
      const rounds = options.rounds || 10000;
      
      const hash = CryptoJS.PBKDF2(password, salt, {
        keySize: 512 / 32,
        iterations: rounds,
      }).toString();
      
      return {
        hash,
        salt,
      };
    }
    
    default:
      throw new Error(`Unsupported hash type: ${type}`);
  }
};

// Verify a password against a hash
export const verifyHash = async (
  password: string,
  hash: string,
  type: string,
  options: any = {}
) => {
  switch (type) {
    case 'plain':
      return password === hash;
    
    case 'md5':
      return CryptoJS.MD5(password).toString() === hash;
    
    case 'sha256':
      return CryptoJS.SHA256(password).toString() === hash;
    
    case 'sha256-salted': {
      const { salt } = options;
      if (!salt) {
        throw new Error('Salt is required for salted SHA-256 verification');
      }
      
      const calculatedHash = CryptoJS.SHA256(salt + password).toString();
      return calculatedHash === hash;
    }
    
    case 'bcrypt':
      return await bcrypt.compare(password, hash);
    
    case 'pbkdf2': {
      const { salt, rounds = 10000 } = options;
      if (!salt) {
        throw new Error('Salt is required for PBKDF2 verification');
      }
      
      const calculatedHash = CryptoJS.PBKDF2(password, salt, {
        keySize: 512 / 32,
        iterations: rounds,
      }).toString();
      
      return calculatedHash === hash;
    }
    
    default:
      throw new Error(`Unsupported hash type: ${type}`);
  }
};

// Measure the performance of different hashing algorithms
export const measureHashingPerformance = async (
  password: string,
  algorithms: Array<{ id: string; name: string; options: any }>
) => {
  const results = [];
  
  for (const algorithm of algorithms) {
    const startTime = performance.now();
    
    // Run the hash function
    await generateHash(password, algorithm.id, algorithm.options);
    
    const endTime = performance.now();
    const timeTaken = (endTime - startTime) / 1000; // Convert to seconds
    
    // Calculate operations per second
    const opsPerSecond = 1 / timeTaken;
    
    results.push({
      name: algorithm.name,
      time: timeTaken,
      opsPerSecond,
    });
  }
  
  // Sort results by time (ascending)
  return results.sort((a, b) => a.time - b.time);
};