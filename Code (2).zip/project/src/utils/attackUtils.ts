import { generateHash, verifyHash } from './hashUtils';
import { applyCommonTransformations } from './passwordUtils';

// Interface for brute force attack parameters
interface BruteForceParams {
  targetHash: string;
  hashType: string;
  charset: string;
  maxLength: number;
  maxAttempts?: number;
  onProgress: (progress: number, attempts: number) => void;
  onComplete: (found: boolean, password: string | null, attempts: number) => void;
}

// Interface for dictionary attack parameters
interface DictionaryAttackParams {
  targetHash: string;
  hashType: string;
  dictionary: string[];
  applyTransforms?: boolean;
  onProgress: (progress: number, attempts: number) => void;
  onComplete: (found: boolean, password: string | null, attempts: number) => void;
}

// Generate all possible combinations for brute force
function* generateCombinations(charset: string, maxLength: number) {
  function* generateHelper(current: string, length: number): Generator<string> {
    if (length === 0) {
      yield current;
      return;
    }
    
    for (let i = 0; i < charset.length; i++) {
      yield* generateHelper(current + charset[i], length - 1);
    }
  }
  
  for (let length = 1; length <= maxLength; length++) {
    yield* generateHelper('', length);
  }
}

// Calculate total possible combinations
export const calculateTotalCombinations = (charset: string, maxLength: number) => {
  let total = 0;
  for (let i = 1; i <= maxLength; i++) {
    total += Math.pow(charset.length, i);
  }
  return total;
};

// Simulate a brute force attack
export const simulateBruteForce = async (params: BruteForceParams) => {
  const {
    targetHash,
    hashType,
    charset,
    maxLength,
    maxAttempts = Infinity,
    onProgress,
    onComplete,
  } = params;
  
  // Calculate the total number of combinations
  const totalCombinations = calculateTotalCombinations(charset, maxLength);
  
  // Limit the total combinations to maxAttempts
  const limitedTotal = Math.min(totalCombinations, maxAttempts);
  
  // Set up the attack
  let attempts = 0;
  let found = false;
  let foundPassword = null;
  
  // Use a generator to avoid generating all combinations at once
  const combinations = generateCombinations(charset, maxLength);
  
  // Simulate the attack using setTimeout to avoid blocking the UI
  const runAttack = async () => {
    const startTime = Date.now();
    const batchSize = 1000; // Process this many passwords per batch
    
    for (let i = 0; i < batchSize; i++) {
      if (attempts >= limitedTotal || found) {
        break;
      }
      
      const next = combinations.next();
      
      if (next.done) {
        break;
      }
      
      const password = next.value;
      attempts++;
      
      // Check if the password matches the hash
      try {
        let isMatch = false;
        
        // For bcrypt, use the verify function
        if (hashType === 'bcrypt') {
          isMatch = await verifyHash(password, targetHash, hashType);
        } else {
          // For other hash types, generate the hash and compare
          const result = await generateHash(password, hashType);
          isMatch = result.hash === targetHash;
        }
        
        if (isMatch) {
          found = true;
          foundPassword = password;
          break;
        }
      } catch (error) {
        console.error('Error checking password:', error);
      }
      
      // Update progress every 100 attempts or so
      if (attempts % 100 === 0) {
        const progress = Math.min(attempts / limitedTotal * 100, 100);
        onProgress(progress, attempts);
      }
    }
    
    const elapsedTime = Date.now() - startTime;
    
    // If we're not done and not found, schedule the next batch
    if (attempts < limitedTotal && !found) {
      onProgress(attempts / limitedTotal * 100, attempts);
      setTimeout(runAttack, 0); // Use setTimeout to give UI a chance to update
    } else {
      // We're done, call the complete callback
      onProgress(found ? 100 : attempts / limitedTotal * 100, attempts);
      onComplete(found, foundPassword, attempts);
    }
  };
  
  // Start the attack
  runAttack();
};

// Simulate a dictionary attack
export const simulateDictionaryAttack = async (params: DictionaryAttackParams) => {
  const {
    targetHash,
    hashType,
    dictionary,
    applyTransforms = true,
    onProgress,
    onComplete,
  } = params;
  
  // Set up the attack
  let attempts = 0;
  let found = false;
  let foundPassword = null;
  
  // Prepare the dictionary
  let wordlist = [...dictionary];
  
  // Add common transformations if requested
  if (applyTransforms) {
    const transformedWords: string[] = [];
    
    for (const word of dictionary) {
      const variations = applyCommonTransformations(word);
      transformedWords.push(...variations);
    }
    
    // Add transformed words to the dictionary
    wordlist = [...new Set([...wordlist, ...transformedWords])];
  }
  
  const totalWords = wordlist.length;
  
  // Simulate the attack using setTimeout to avoid blocking the UI
  const runAttack = async () => {
    const startTime = Date.now();
    const batchSize = 100; // Process this many passwords per batch
    const startIndex = attempts;
    const endIndex = Math.min(startIndex + batchSize, totalWords);
    
    for (let i = startIndex; i < endIndex; i++) {
      const password = wordlist[i];
      attempts++;
      
      // Check if the password matches the hash
      try {
        let isMatch = false;
        
        // For bcrypt, use the verify function
        if (hashType === 'bcrypt') {
          isMatch = await verifyHash(password, targetHash, hashType);
        } else {
          // For other hash types, generate the hash and compare
          const result = await generateHash(password, hashType);
          isMatch = result.hash === targetHash;
        }
        
        if (isMatch) {
          found = true;
          foundPassword = password;
          break;
        }
      } catch (error) {
        console.error('Error checking password:', error);
      }
      
      // Update progress every 10 attempts or so
      if (attempts % 10 === 0) {
        const progress = Math.min(attempts / totalWords * 100, 100);
        onProgress(progress, attempts);
      }
    }
    
    const elapsedTime = Date.now() - startTime;
    
    // If we're not done and not found, schedule the next batch
    if (attempts < totalWords && !found) {
      onProgress(attempts / totalWords * 100, attempts);
      setTimeout(runAttack, 0); // Use setTimeout to give UI a chance to update
    } else {
      // We're done, call the complete callback
      onProgress(found ? 100 : attempts / totalWords * 100, attempts);
      onComplete(found, foundPassword, attempts);
    }
  };
  
  // Start the attack
  runAttack();
};