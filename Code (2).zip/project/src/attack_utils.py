import string
import time
import random
import itertools
from tqdm import tqdm
import hashlib

class PasswordGenerator:
    """
    A class that provides methods to generate passwords for brute force attacks.
    """
    
    @staticmethod
    def generate_all_combinations(charset, min_length, max_length):
        """Generate all possible combinations of characters within length range"""
        for length in range(min_length, max_length + 1):
            for combination in itertools.product(charset, repeat=length):
                yield ''.join(combination)
    
    @staticmethod
    def common_password_list(file_path=None):
        """Load common passwords from a file or use a default list"""
        if file_path:
            try:
                with open(file_path, 'r') as f:
                    return [line.strip() for line in f]
            except FileNotFoundError:
                print(f"Warning: Password file {file_path} not found. Using default list.")
        
        # Default small list of common passwords for demonstration
        return [
            "password", "123456", "12345678", "qwerty", "abc123", 
            "monkey", "1234567", "letmein", "trustno1", "dragon", 
            "baseball", "111111", "iloveyou", "master", "sunshine", 
            "ashley", "bailey", "passw0rd", "shadow", "123123", 
            "654321", "superman", "qazwsx", "michael", "football"
        ]


class BruteForceAttack:
    """
    A class that simulates brute force attacks on password hashes.
    """
    
    def __init__(self, hash_function, verify_function=None):
        """
        Initialize the brute force attack.
        
        Args:
            hash_function: Function that takes a password and returns a hash
            verify_function: Function that verifies a password against a hash
        """
        self.hash_function = hash_function
        self.verify_function = verify_function
    
    def attack_hash(self, target_hash, charset=None, min_length=1, max_length=8, 
                   salt=None, max_attempts=None, verbose=True):
        """
        Attempt to crack a hash using brute force.
        
        Args:
            target_hash: The hash to crack
            charset: Character set to use (default: lowercase + digits)
            min_length: Minimum password length to try
            max_length: Maximum password length to try
            salt: Salt used for the hash (if applicable)
            max_attempts: Maximum number of attempts before giving up
            verbose: Whether to show progress
            
        Returns:
            tuple: (cracked_password, attempts, time_taken) or (None, attempts, time_taken)
        """
        if charset is None:
            charset = string.ascii_lowercase + string.digits
        
        attempts = 0
        start_time = time.time()
        
        # Create a generator for all possible combinations
        combinations = PasswordGenerator.generate_all_combinations(charset, min_length, max_length)
        
        if verbose:
            # Calculate total combinations for progress bar
            total_combinations = sum(len(charset) ** length for length in range(min_length, max_length + 1))
            if max_attempts and max_attempts < total_combinations:
                total_combinations = max_attempts
            
            combinations = tqdm(combinations, total=total_combinations, 
                               desc="Brute force attack", unit="attempt")
        
        for password in combinations:
            attempts += 1
            
            # Check if we've hit the maximum number of attempts
            if max_attempts and attempts >= max_attempts:
                if verbose:
                    print(f"Reached maximum attempts ({max_attempts}). Stopping attack.")
                break
            
            # If we have a verify function, use it
            if self.verify_function:
                if salt:
                    is_match = self.verify_function(target_hash, salt, password)
                else:
                    is_match = self.verify_function(target_hash, password)
            else:
                # Otherwise, hash the password and compare
                if salt:
                    current_hash = self.hash_function(password, salt)['hash']
                else:
                    current_hash = self.hash_function(password)
                    
                is_match = (current_hash == target_hash)
            
            # If we found a match, return the password
            if is_match:
                time_taken = time.time() - start_time
                return password, attempts, time_taken
        
        # If we didn't find a match, return None
        time_taken = time.time() - start_time
        return None, attempts, time_taken


class DictionaryAttack:
    """
    A class that simulates dictionary attacks on password hashes.
    """
    
    def __init__(self, hash_function, verify_function=None):
        """
        Initialize the dictionary attack.
        
        Args:
            hash_function: Function that takes a password and returns a hash
            verify_function: Function that verifies a password against a hash
        """
        self.hash_function = hash_function
        self.verify_function = verify_function
    
    def attack_hash(self, target_hash, dictionary=None, salt=None, 
                   apply_common_transforms=True, verbose=True):
        """
        Attempt to crack a hash using a dictionary attack.
        
        Args:
            target_hash: The hash to crack
            dictionary: List of words to try (default: common password list)
            salt: Salt used for the hash (if applicable)
            apply_common_transforms: Whether to apply common password transformations
            verbose: Whether to show progress
            
        Returns:
            tuple: (cracked_password, attempts, time_taken) or (None, attempts, time_taken)
        """
        if dictionary is None:
            dictionary = PasswordGenerator.common_password_list()
        
        attempts = 0
        start_time = time.time()
        
        # Expand dictionary with common transforms if requested
        expanded_dict = dictionary.copy()
        if apply_common_transforms:
            for word in dictionary:
                # Add capitalized version
                expanded_dict.append(word.capitalize())
                
                # Add common number suffixes
                for i in range(10):
                    expanded_dict.append(f"{word}{i}")
                expanded_dict.append(f"{word}123")
                expanded_dict.append(f"{word}1234")
                
                # Add common symbol replacements
                expanded_dict.append(word.replace('a', '@'))
                expanded_dict.append(word.replace('e', '3'))
                expanded_dict.append(word.replace('i', '1'))
                expanded_dict.append(word.replace('o', '0'))
                expanded_dict.append(word.replace('s', '$'))
        
        # Remove duplicates
        expanded_dict = list(set(expanded_dict))
        
        if verbose:
            expanded_dict = tqdm(expanded_dict, desc="Dictionary attack", unit="word")
        
        for password in expanded_dict:
            attempts += 1
            
            # If we have a verify function, use it
            if self.verify_function:
                if salt:
                    is_match = self.verify_function(target_hash, salt, password)
                else:
                    is_match = self.verify_function(target_hash, password)
            else:
                # Otherwise, hash the password and compare
                if salt:
                    current_hash = self.hash_function(password, salt)['hash']
                else:
                    current_hash = self.hash_function(password)
                    
                is_match = (current_hash == target_hash)
            
            # If we found a match, return the password
            if is_match:
                time_taken = time.time() - start_time
                return password, attempts, time_taken
        
        # If we didn't find a match, return None
        time_taken = time.time() - start_time
        return None, attempts, time_taken