#!/usr/bin/env python3
"""
Password Cracking & Encryption Demo
A Python-based simulation of password hashing, encryption, and attack methods.
"""

import os
import sys
import argparse
from colorama import init, Fore, Style

# Import our modules
from demo import PasswordDemo
from hash_utils import HashingMethods
from attack_utils import BruteForceAttack, DictionaryAttack
from password_strength import PasswordStrengthAnalyzer

# Initialize colorama for colored terminal output
init(autoreset=True)

def print_banner():
    """Print a banner for the application"""
    banner = """
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║   Password Security Demonstration                             ║
    ║   Hashing · Encryption · Password Cracking                    ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
    """
    print(f"{Fore.CYAN}{Style.BRIGHT}{banner}")

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="Password Security Demo - Educational tool for demonstrating password security concepts"
    )
    
    # Main commands
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Demo command - run interactive demos
    demo_parser = subparsers.add_parser("demo", help="Run interactive demonstrations")
    demo_parser.add_argument(
        "--module", 
        choices=["all", "hashing", "brute-force", "dictionary", "strength", "comparison"],
        default="all",
        help="Specific demo module to run (default: all)"
    )
    
    # Hash command - hash a password
    hash_parser = subparsers.add_parser("hash", help="Hash a password with various algorithms")
    hash_parser.add_argument("password", help="Password to hash")
    hash_parser.add_argument(
        "--algorithm", 
        choices=["md5", "sha256", "salted-sha256", "bcrypt", "pbkdf2"],
        default="bcrypt",
        help="Hashing algorithm to use (default: bcrypt)"
    )
    hash_parser.add_argument(
        "--rounds", 
        type=int,
        default=12,
        help="Number of rounds for bcrypt or PBKDF2 (default: 12 for bcrypt, 100000 for PBKDF2)"
    )
    
    # Analyze command - analyze password strength
    analyze_parser = subparsers.add_parser("analyze", help="Analyze password strength")
    analyze_parser.add_argument("password", help="Password to analyze")
    
    # Attack command - simulate an attack on a password hash
    attack_parser = subparsers.add_parser("attack", help="Simulate an attack on a password hash")
    attack_parser.add_argument("hash", help="Hash to attack")
    attack_parser.add_argument(
        "--type", 
        choices=["brute-force", "dictionary"],
        default="dictionary",
        help="Attack type (default: dictionary)"
    )
    attack_parser.add_argument(
        "--algorithm", 
        choices=["md5", "sha256", "salted-sha256", "bcrypt"],
        default="sha256",
        help="Hash algorithm (default: sha256)"
    )
    attack_parser.add_argument(
        "--salt", 
        help="Salt for salted hashes (hex encoded)"
    )
    attack_parser.add_argument(
        "--min-length", 
        type=int,
        default=1,
        help="Minimum password length for brute force (default: 1)"
    )
    attack_parser.add_argument(
        "--max-length", 
        type=int,
        default=8,
        help="Maximum password length for brute force (default: 8)"
    )
    attack_parser.add_argument(
        "--charset", 
        default="abcdefghijklmnopqrstuvwxyz0123456789",
        help="Character set for brute force (default: lowercase + digits)"
    )
    attack_parser.add_argument(
        "--dictionary", 
        help="Path to dictionary file"
    )
    attack_parser.add_argument(
        "--max-attempts", 
        type=int,
        default=1000000,
        help="Maximum attempts before giving up (default: 1,000,000)"
    )
    
    args = parser.parse_args()
    
    # If no command is specified, show help
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    return args

def run_demo(args):
    """Run the interactive demo"""
    demo = PasswordDemo()
    
    if args.module == "all":
        demo.run_all_demos()
    elif args.module == "hashing":
        demo.demonstrate_hashing_methods()
    elif args.module == "brute-force":
        demo.demonstrate_brute_force()
    elif args.module == "dictionary":
        demo.demonstrate_dictionary_attack()
    elif args.module == "strength":
        demo.demonstrate_password_strength()
    elif args.module == "comparison":
        demo.demonstrate_hash_comparison()

def hash_password(args):
    """Hash a password with the specified algorithm"""
    hashing = HashingMethods()
    
    print(f"{Fore.CYAN}{Style.BRIGHT}Hashing password with {args.algorithm}")
    
    if args.algorithm == "md5":
        result = hashing.simple_md5(args.password)
        print(f"\nMD5 hash: {result}")
        print(f"{Fore.RED}Warning: MD5 is insecure and should not be used for passwords!")
        
    elif args.algorithm == "sha256":
        result = hashing.simple_sha256(args.password)
        print(f"\nSHA-256 hash: {result}")
        print(f"{Fore.YELLOW}Warning: SHA-256 without salt is vulnerable to rainbow table attacks!")
        
    elif args.algorithm == "salted-sha256":
        result = hashing.salted_sha256(args.password)
        print(f"\nSalt (hex): {result['salt'].hex()}")
        print(f"Salted SHA-256 hash: {result['hash']}")
        print(f"{Fore.YELLOW}Note: While salted SHA-256 is better than plain SHA-256, specialized")
        print(f"{Fore.YELLOW}password hashing algorithms like bcrypt are recommended.")
        
    elif args.algorithm == "bcrypt":
        result = hashing.bcrypt_hash(args.password, rounds=args.rounds)
        print(f"\nBcrypt hash (rounds={args.rounds}): {result}")
        print(f"{Fore.GREEN}Bcrypt is a good choice for password hashing!")
        
    elif args.algorithm == "pbkdf2":
        rounds = args.rounds if args.rounds != 12 else 100000  # Use default of 100000 if not changed
        result = hashing.pbkdf2_hash(args.password, rounds=rounds)
        print(f"\nPBKDF2 hash (rounds={rounds}): {result}")
        print(f"{Fore.GREEN}PBKDF2 is a good choice for password hashing!")

def analyze_password(args):
    """Analyze the strength of a password"""
    analyzer = PasswordStrengthAnalyzer()
    analysis = analyzer.analyze_password(args.password)
    
    print(f"{Fore.CYAN}{Style.BRIGHT}Password Strength Analysis")
    print(f"{Fore.CYAN}{'='*50}")
    
    # Color-code the strength
    if analysis["strength"] == "Very Weak":
        strength_colored = f"{Fore.RED}{Style.BRIGHT}{analysis['strength']}"
    elif analysis["strength"] == "Weak":
        strength_colored = f"{Fore.RED}{analysis['strength']}"
    elif analysis["strength"] == "Moderate":
        strength_colored = f"{Fore.YELLOW}{analysis['strength']}"
    elif analysis["strength"] == "Strong":
        strength_colored = f"{Fore.GREEN}{analysis['strength']}"
    else:
        strength_colored = f"{Fore.GREEN}{Style.BRIGHT}{analysis['strength']}"
    
    print(f"\nPassword: {args.password}")
    print(f"Length: {analysis['length']} characters")
    print(f"Entropy: {analysis['entropy']:.2f} bits")
    print(f"Strength: {strength_colored}")
    print(f"Estimated crack time: {analysis['estimated_crack_time']}")
    
    # Character composition
    comp = analysis["character_composition"]
    print("\nCharacter Composition:")
    print(f"  Lowercase: {comp['lowercase']} ({comp['lowercase']/analysis['length']*100:.1f}%)")
    print(f"  Uppercase: {comp['uppercase']} ({comp['uppercase']/analysis['length']*100:.1f}%)")
    print(f"  Digits: {comp['digits']} ({comp['digits']/analysis['length']*100:.1f}%)")
    print(f"  Symbols: {comp['symbols']} ({comp['symbols']/analysis['length']*100:.1f}%)")
    
    # Patterns found
    if analysis["patterns_found"]:
        print("\nPatterns Found:")
        for pattern in analysis["patterns_found"]:
            print(f"{Fore.YELLOW}⚠️  {pattern}")
    
    # Suggestions
    if analysis["improvement_suggestions"]:
        print("\nImprovement Suggestions:")
        for suggestion in analysis["improvement_suggestions"]:
            print(f"{Fore.BLUE}→ {suggestion}")

def simulate_attack(args):
    """Simulate an attack on a password hash"""
    hashing = HashingMethods()
    
    print(f"{Fore.CYAN}{Style.BRIGHT}Simulating {args.type} attack on {args.algorithm} hash")
    
    # Set up the appropriate hash function based on algorithm
    if args.algorithm == "md5":
        hash_func = hashing.simple_md5
    elif args.algorithm == "sha256":
        hash_func = hashing.simple_sha256
    elif args.algorithm == "salted-sha256":
        if not args.salt:
            print(f"{Fore.RED}Error: Salt is required for salted-sha256")
            sys.exit(1)
        salt = bytes.fromhex(args.salt)
        hash_func = lambda p: hashing.salted_sha256(p, salt=salt)['hash']
    elif args.algorithm == "bcrypt":
        # For bcrypt, we'll use a verify function instead of a hash function
        def verify_bcrypt(stored_hash, password):
            import bcrypt
            return bcrypt.checkpw(password.encode(), stored_hash.encode())
        hash_func = None
        verify_func = verify_bcrypt
    
    # Run the appropriate attack
    if args.type == "brute-force":
        print(f"\nBrute force parameters:")
        print(f"  Character set: {args.charset}")
        print(f"  Password length range: {args.min_length}-{args.max_length}")
        print(f"  Maximum attempts: {args.max_attempts:,}")
        
        if args.algorithm == "bcrypt":
            bf_attack = BruteForceAttack(None, verify_func)
        else:
            bf_attack = BruteForceAttack(hash_func)
        
        result, attempts, time_taken = bf_attack.attack_hash(
            args.hash, 
            charset=args.charset,
            min_length=args.min_length,
            max_length=args.max_length,
            salt=bytes.fromhex(args.salt) if args.salt else None,
            max_attempts=args.max_attempts
        )
    
    elif args.type == "dictionary":
        print(f"\nDictionary attack parameters:")
        if args.dictionary:
            print(f"  Dictionary file: {args.dictionary}")
        else:
            print(f"  Using built-in common password list")
        print(f"  Maximum attempts: {args.max_attempts:,}")
        
        if args.algorithm == "bcrypt":
            dict_attack = DictionaryAttack(None, verify_func)
        else:
            dict_attack = DictionaryAttack(hash_func)
        
        # Load dictionary if specified
        dictionary = None
        if args.dictionary:
            try:
                with open(args.dictionary, 'r') as f:
                    dictionary = [line.strip() for line in f]
                print(f"  Loaded {len(dictionary):,} words from dictionary")
            except FileNotFoundError:
                print(f"{Fore.RED}Error: Dictionary file not found: {args.dictionary}")
                sys.exit(1)
        
        result, attempts, time_taken = dict_attack.attack_hash(
            args.hash,
            dictionary=dictionary,
            salt=bytes.fromhex(args.salt) if args.salt else None,
            apply_common_transforms=True
        )
    
    # Display results
    if result:
        print(f"\n{Fore.GREEN}{Style.BRIGHT}Password cracked: {result}")
        print(f"Attempts: {attempts:,}")
        print(f"Time taken: {time_taken:.4f} seconds")
        print(f"Attempts per second: {attempts/time_taken:.1f}")
    else:
        print(f"\n{Fore.RED}{Style.BRIGHT}Failed to crack password")
        print(f"Attempts made: {attempts:,}")
        print(f"Time taken: {time_taken:.4f} seconds")
        print(f"Attempts per second: {attempts/time_taken:.1f}")

def main():
    """Main entry point for the application"""
    print_banner()
    args = parse_arguments()
    
    # Run the appropriate command
    if args.command == "demo":
        run_demo(args)
    elif args.command == "hash":
        hash_password(args)
    elif args.command == "analyze":
        analyze_password(args)
    elif args.command == "attack":
        simulate_attack(args)

if __name__ == "__main__":
    main()