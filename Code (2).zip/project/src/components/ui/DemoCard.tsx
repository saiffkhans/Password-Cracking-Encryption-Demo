import React, { ReactNode } from 'react';

interface DemoCardProps {
  title: string;
  children: ReactNode;
}

const DemoCard: React.FC<DemoCardProps> = ({ title, children }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      <div className="px-6 py-4 bg-blue-800 dark:bg-blue-900">
        <h2 className="text-xl font-bold text-white">{title}</h2>
      </div>
      <div className="p-6">
        {children}
      </div>
    </div>
  );
};

export default DemoCard;