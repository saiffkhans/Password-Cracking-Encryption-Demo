import React from 'react';

interface ProgressBarProps {
  value: number;
  max?: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ value, max = 100 }) => {
  const percentage = Math.min(Math.max(0, (value / max) * 100), 100);
  
  let color = 'bg-blue-500';
  if (percentage < 25) {
    color = 'bg-red-500';
  } else if (percentage < 50) {
    color = 'bg-orange-500';
  } else if (percentage < 75) {
    color = 'bg-yellow-500';
  } else {
    color = 'bg-green-500';
  }

  return (
    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4 overflow-hidden">
      <div
        className={`h-full ${color} transition-all duration-300 ease-out flex items-center justify-end pr-2`}
        style={{ width: `${percentage}%` }}
      >
        {percentage >= 10 && (
          <span className="text-white text-xs font-semibold">
            {Math.round(percentage)}%
          </span>
        )}
      </div>
    </div>
  );
};

export default ProgressBar;