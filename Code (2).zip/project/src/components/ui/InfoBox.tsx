import React, { ReactNode } from 'react';

interface InfoBoxProps {
  children: ReactNode;
  type?: 'info' | 'warning' | 'success' | 'error';
  icon?: ReactNode;
}

const InfoBox: React.FC<InfoBoxProps> = ({
  children,
  type = 'info',
  icon,
}) => {
  const typeClasses = {
    info: 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300',
    warning: 'bg-yellow-50 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300',
    success: 'bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-300',
    error: 'bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300',
  };

  return (
    <div className={`p-4 rounded-md ${typeClasses[type]}`}>
      <div className="flex">
        {icon && <div className="flex-shrink-0 mr-3">{icon}</div>}
        <div>{children}</div>
      </div>
    </div>
  );
};

export default InfoBox;