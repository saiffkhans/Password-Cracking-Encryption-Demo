import React, { useState, useEffect } from 'react';
import DemoCard from '../ui/DemoCard';
import InputField from '../ui/InputField';
import { Shield, AlertTriangle, Check, X, Info } from 'lucide-react';
import { analyzePasswordStrength } from '../../utils/passwordUtils';

const PasswordStrengthDemo = () => {
  const [password, setPassword] = useState('');
  const [analysis, setAnalysis] = useState<any>(null);

  useEffect(() => {
    if (password) {
      const result = analyzePasswordStrength(password);
      setAnalysis(result);
    } else {
      setAnalysis(null);
    }
  }, [password]);

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'Very Weak':
        return 'text-red-600 dark:text-red-400';
      case 'Weak':
        return 'text-red-500 dark:text-red-300';
      case 'Moderate':
        return 'text-yellow-500 dark:text-yellow-400';
      case 'Strong':
        return 'text-green-500 dark:text-green-400';
      case 'Very Strong':
        return 'text-green-600 dark:text-green-300';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getStrengthMeter = () => {
    if (!analysis) return null;
    
    const { entropy } = analysis;
    let value = 0;
    let color = 'bg-red-500';
    
    if (entropy < 28) {
      value = 20;
      color = 'bg-red-600';
    } else if (entropy < 36) {
      value = 40;
      color = 'bg-red-500';
    } else if (entropy < 60) {
      value = 60;
      color = 'bg-yellow-500';
    } else if (entropy < 80) {
      value = 80;
      color = 'bg-green-500';
    } else {
      value = 100;
      color = 'bg-green-600';
    }
    
    return (
      <div className="mb-6">
        <div className="h-2 w-full bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div 
            className={`h-full ${color} transition-all duration-300 ease-out`}
            style={{ width: `${value}%` }}
          ></div>
        </div>
      </div>
    );
  };

  const samplePasswords = [
    { text: 'password', label: 'Common Password' },
    { text: 'Password1', label: 'With Capital & Number' },
    { text: 'P@ssw0rd', label: 'With Symbols' },
    { text: 'CorrectHorseBatteryStaple', label: 'Long Passphrase' },
    { text: 'xT5!9pQ#2mLz@7', label: 'Complex Random' },
  ];

  return (
    <DemoCard title="Password Strength Analyzer">
      <div className="mb-6">
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          Enter a password to analyze its strength. The analyzer will check length, character complexity,
          common patterns, and calculate entropy to determine how resistant it is to attacks.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="md:col-span-2">
          <InputField
            label="Password to Analyze"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter a password to analyze"
            type="password"
            toggleVisibility
          />
          
          <div className="mt-4">
            <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">Sample passwords to try:</div>
            <div className="flex flex-wrap gap-2">
              {samplePasswords.map((sample, index) => (
                <button
                  key={index}
                  onClick={() => setPassword(sample.text)}
                  className="inline-flex items-center px-2 py-1 text-xs rounded-md bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 transition-colors"
                  title={sample.label}
                >
                  {sample.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
          <h4 className="font-medium flex items-center text-blue-800 dark:text-blue-300 mb-2">
            <Info size={16} className="mr-2" />
            Password Entropy
          </h4>
          <p className="text-sm text-blue-700 dark:text-blue-200 mb-2">
            Entropy measures password unpredictability in bits. Higher is better.
          </p>
          <ul className="text-xs text-blue-600 dark:text-blue-300 space-y-1">
            <li>• &lt;28 bits: Very weak, instant cracking</li>
            <li>• 28-35 bits: Weak, minutes to hours</li>
            <li>• 36-59 bits: Moderate, days to weeks</li>
            <li>• 60-80 bits: Strong, years</li>
            <li>• &gt;80 bits: Very strong, centuries</li>
          </ul>
        </div>
      </div>
      
      {analysis && (
        <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
          <div className="flex items-center mb-4">
            <Shield size={20} className="mr-2" />
            <h3 className="font-medium text-lg">Analysis Results</h3>
          </div>
          
          {getStrengthMeter()}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="mb-6">
                <div className="text-gray-700 dark:text-gray-300 font-medium mb-2">Password Strength</div>
                <div className={`text-2xl font-bold ${getStrengthColor(analysis.strength)}`}>
                  {analysis.strength}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  Estimated crack time: {analysis.estimated_crack_time}
                </div>
              </div>
              
              <div className="mb-6">
                <div className="text-gray-700 dark:text-gray-300 font-medium mb-2">Metrics</div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Length:</span>
                    <span className="font-medium">{analysis.length} characters</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Entropy:</span>
                    <span className="font-medium">{analysis.entropy.toFixed(2)} bits</span>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="text-gray-700 dark:text-gray-300 font-medium mb-2">Character Composition</div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                  {Object.entries(analysis.character_composition).map(([key, value]: [string, any]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400 capitalize">{key}:</span>
                      <span className="font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div>
              {analysis.patterns_found.length > 0 && (
                <div className="mb-6">
                  <div className="text-red-600 dark:text-red-400 font-medium flex items-center mb-2">
                    <AlertTriangle size={16} className="mr-2" />
                    <span>Patterns Detected</span>
                  </div>
                  <ul className="space-y-2">
                    {analysis.patterns_found.map((pattern: string, index: number) => (
                      <li key={index} className="flex items-start">
                        <X size={16} className="mr-2 text-red-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{pattern}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {analysis.improvement_suggestions.length > 0 && (
                <div>
                  <div className="text-green-600 dark:text-green-400 font-medium flex items-center mb-2">
                    <Info size={16} className="mr-2" />
                    <span>Improvement Suggestions</span>
                  </div>
                  <ul className="space-y-2">
                    {analysis.improvement_suggestions.map((suggestion: string, index: number) => (
                      <li key={index} className="flex items-start">
                        <Check size={16} className="mr-2 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{suggestion}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {!analysis && password && (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          Analyzing password...
        </div>
      )}
      
      {!analysis && !password && (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          Enter a password above to see analysis results
        </div>
      )}
    </DemoCard>
  );
};

export default PasswordStrengthDemo;