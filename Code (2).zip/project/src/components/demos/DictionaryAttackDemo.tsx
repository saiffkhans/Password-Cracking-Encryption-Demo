import React, { useState, useEffect, useRef } from 'react';
import DemoCard from '../ui/DemoCard';
import InputField from '../ui/InputField';
import Button from '../ui/Button';
import ProgressBar from '../ui/ProgressBar';
import InfoBox from '../ui/InfoBox';
import { AlertTriangle, Info, Play, Timer, History } from 'lucide-react';
import { generateHash } from '../../utils/hashUtils';
import { simulateDictionaryAttack } from '../../utils/attackUtils';
import { getCommonPasswords } from '../../utils/passwordUtils';

const DictionaryAttackDemo = () => {
  const [password, setPassword] = useState('password123');
  const [hashType, setHashType] = useState('sha256');
  const [applyTransforms, setApplyTransforms] = useState(true);
  const [hashValue, setHashValue] = useState('');
  const [isAttacking, setIsAttacking] = useState(false);
  const [progress, setProgress] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [timeTaken, setTimeTaken] = useState(0);
  const [result, setResult] = useState<{ found: boolean; password?: string } | null>(null);
  const [commonPasswords, setCommonPasswords] = useState<string[]>([]);

  const attackIntervalRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);

  useEffect(() => {
    // Load common passwords
    setCommonPasswords(getCommonPasswords());
  }, []);

  useEffect(() => {
    const updateHash = async () => {
      const hashResult = await generateHash(password, hashType);
      setHashValue(hashResult.hash);
    };
    updateHash();
  }, [password, hashType]);

  const startAttack = () => {
    if (isAttacking) return;
    
    setIsAttacking(true);
    setProgress(0);
    setAttempts(0);
    setTimeTaken(0);
    setResult(null);
    
    startTimeRef.current = Date.now();
    
    // Start the simulation
    attackIntervalRef.current = window.setInterval(() => {
      setTimeTaken((Date.now() - startTimeRef.current) / 1000);
    }, 100);
    
    simulateDictionaryAttack({
      targetHash: hashValue,
      hashType,
      dictionary: commonPasswords,
      applyTransforms,
      onProgress: (currentProgress, currentAttempts) => {
        setProgress(currentProgress);
        setAttempts(currentAttempts);
      },
      onComplete: (found, crackedPassword, totalAttempts) => {
        clearInterval(attackIntervalRef.current as number);
        attackIntervalRef.current = null;
        
        setIsAttacking(false);
        setAttempts(totalAttempts);
        setTimeTaken((Date.now() - startTimeRef.current) / 1000);
        
        if (found) {
          setResult({ found: true, password: crackedPassword });
        } else {
          setResult({ found: false });
        }
      }
    });
  };

  const stopAttack = () => {
    if (attackIntervalRef.current !== null) {
      clearInterval(attackIntervalRef.current);
      attackIntervalRef.current = null;
    }
    setIsAttacking(false);
  };

  useEffect(() => {
    return () => {
      if (attackIntervalRef.current !== null) {
        clearInterval(attackIntervalRef.current);
      }
    };
  }, []);

  return (
    <DemoCard title="Dictionary Attack Simulation">
      <div className="mb-6">
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          This simulation demonstrates how a dictionary attack works by trying common passwords
          and variations instead of every possible combination.
        </p>
        
        <InfoBox type="info" icon={<Info size={16} />}>
          Dictionary attacks are often much faster than brute force attacks because they target
          common passwords that people actually use. They can crack weak passwords in seconds
          that might take years with brute force.
        </InfoBox>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="font-medium text-lg mb-4">Target Password Setup</h3>
          
          <InputField
            label="Password to Crack"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter a password"
            disabled={isAttacking}
          />
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Hash Algorithm
            </label>
            <select
              value={hashType}
              onChange={(e) => setHashType(e.target.value)}
              className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
              disabled={isAttacking}
            >
              <option value="md5">MD5 (Fast, Insecure)</option>
              <option value="sha256">SHA-256 (No Salt)</option>
              <option value="bcrypt">Bcrypt (Slow, Secure)</option>
            </select>
          </div>
          
          <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-md mb-4">
            <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">Generated Hash:</div>
            <div className="font-mono text-xs break-all">{hashValue}</div>
          </div>
        </div>
        
        <div>
          <h3 className="font-medium text-lg mb-4">Attack Parameters</h3>
          
          <div className="mb-6">
            <div className="flex items-center mb-2">
              <input
                type="checkbox"
                id="applyTransforms"
                checked={applyTransforms}
                onChange={(e) => setApplyTransforms(e.target.checked)}
                className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                disabled={isAttacking}
              />
              <label htmlFor="applyTransforms" className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                Apply Common Transformations
              </label>
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              When enabled, the attack will try variations like capitalizing, adding numbers, 
              and replacing letters with similar symbols (e.g., 'a' → '@').
            </p>
          </div>
          
          <div className="mb-4">
            <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Dictionary Size
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              {commonPasswords.length} common passwords
              {applyTransforms && " (plus variations)"}
            </div>
          </div>
          
          <div className="flex space-x-3">
            <Button 
              onClick={startAttack} 
              disabled={isAttacking}
              color="blue"
              icon={<Play size={16} />}
            >
              Start Attack
            </Button>
            
            <Button 
              onClick={stopAttack} 
              disabled={!isAttacking}
              color="red"
            >
              Stop Attack
            </Button>
          </div>
        </div>
      </div>
      
      <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
        <h3 className="font-medium text-lg mb-4">Attack Progress</h3>
        
        <ProgressBar value={progress} />
        
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-md">
            <div className="flex items-center text-gray-700 dark:text-gray-300 mb-1">
              <History size={16} className="mr-2" />
              <span className="text-sm font-medium">Attempts</span>
            </div>
            <div className="text-2xl font-semibold">{attempts.toLocaleString()}</div>
          </div>
          
          <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-md">
            <div className="flex items-center text-gray-700 dark:text-gray-300 mb-1">
              <Timer size={16} className="mr-2" />
              <span className="text-sm font-medium">Time Elapsed</span>
            </div>
            <div className="text-2xl font-semibold">{timeTaken.toFixed(2)}s</div>
          </div>
          
          <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-md">
            <div className="flex items-center text-gray-700 dark:text-gray-300 mb-1">
              <span className="text-sm font-medium">Attempts/Second</span>
            </div>
            <div className="text-2xl font-semibold">
              {timeTaken > 0 ? Math.round(attempts / timeTaken).toLocaleString() : 0}
            </div>
          </div>
        </div>
        
        {result && (
          <div className={`mt-6 p-4 rounded-md ${result.found ? 'bg-green-100 dark:bg-green-900' : 'bg-red-100 dark:bg-red-900'}`}>
            {result.found ? (
              <div>
                <h4 className="font-medium text-green-800 dark:text-green-300 mb-1">Password Cracked!</h4>
                <p className="text-green-700 dark:text-green-200">
                  Found password: <span className="font-mono font-bold">{result.password}</span> in {attempts.toLocaleString()} attempts
                </p>
              </div>
            ) : (
              <div>
                <h4 className="font-medium text-red-800 dark:text-red-300 mb-1">Attack Failed</h4>
                <p className="text-red-700 dark:text-red-200">
                  Password not found in dictionary of {attempts.toLocaleString()} words/variations
                </p>
                <p className="text-red-700 dark:text-red-200 mt-1">
                  This is good! It means your password isn't among common passwords.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </DemoCard>
  );
};

export default DictionaryAttackDemo;