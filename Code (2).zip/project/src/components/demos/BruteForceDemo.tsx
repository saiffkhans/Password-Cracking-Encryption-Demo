import React, { useState, useEffect, useRef } from 'react';
import DemoCard from '../ui/DemoCard';
import InputField from '../ui/InputField';
import Button from '../ui/Button';
import ProgressBar from '../ui/ProgressBar';
import InfoBox from '../ui/InfoBox';
import { AlertTriangle, Play, Timer, History } from 'lucide-react';
import { generateHash } from '../../utils/hashUtils';
import { simulateBruteForce } from '../../utils/attackUtils';

const BruteForceDemo = () => {
  const [password, setPassword] = useState('abc123');
  const [hashType, setHashType] = useState('sha256');
  const [charsetType, setCharsetType] = useState('alphanumeric');
  const [maxLength, setMaxLength] = useState(6);
  const [hashValue, setHashValue] = useState('');
  const [isAttacking, setIsAttacking] = useState(false);
  const [progress, setProgress] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [timeTaken, setTimeTaken] = useState(0);
  const [result, setResult] = useState<{ found: boolean; password?: string } | null>(null);
  const [estimatedTime, setEstimatedTime] = useState<string | null>(null);

  const attackIntervalRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);

  useEffect(() => {
    const updateHash = async () => {
      const hashResult = await generateHash(password, hashType);
      setHashValue(hashResult.hash);
    };
    updateHash();
  }, [password, hashType]);

  const getCharset = () => {
    switch (charsetType) {
      case 'lowercase':
        return 'abcdefghijklmnopqrstuvwxyz';
      case 'alphanumeric':
        return 'abcdefghijklmnopqrstuvwxyz0123456789';
      case 'full':
        return 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      default:
        return 'abcdefghijklmnopqrstuvwxyz0123456789';
    }
  };

  const startAttack = () => {
    if (isAttacking) return;
    
    setIsAttacking(true);
    setProgress(0);
    setAttempts(0);
    setTimeTaken(0);
    setResult(null);
    
    const charset = getCharset();
    const maxAttempts = 100000; // Limit for demonstration purposes
    startTimeRef.current = Date.now();
    
    // Start the simulation
    attackIntervalRef.current = window.setInterval(() => {
      setTimeTaken((Date.now() - startTimeRef.current) / 1000);
    }, 100);
    
    simulateBruteForce({
      targetHash: hashValue,
      hashType,
      charset,
      maxLength,
      maxAttempts,
      onProgress: (currentProgress, currentAttempts) => {
        setProgress(currentProgress);
        setAttempts(currentAttempts);
      },
      onComplete: (found, crackedPassword, totalAttempts) => {
        clearInterval(attackIntervalRef.current as number);
        attackIntervalRef.current = null;
        
        setIsAttacking(false);
        setAttempts(totalAttempts);
        setTimeTaken((Date.now() - startTimeRef.current) / 1000);
        
        if (found) {
          setResult({ found: true, password: crackedPassword });
        } else {
          setResult({ found: false });
          // Calculate estimated time based on the current rate
          const attemptsPerSecond = totalAttempts / ((Date.now() - startTimeRef.current) / 1000);
          const totalPossibleCombinations = calculateTotalCombinations(charset.length, maxLength);
          const estimatedSeconds = totalPossibleCombinations / attemptsPerSecond;
          setEstimatedTime(formatEstimatedTime(estimatedSeconds));
        }
      }
    });
  };

  const stopAttack = () => {
    if (attackIntervalRef.current !== null) {
      clearInterval(attackIntervalRef.current);
      attackIntervalRef.current = null;
    }
    setIsAttacking(false);
  };

  const calculateTotalCombinations = (charsetLength: number, maxLen: number) => {
    let total = 0;
    for (let i = 1; i <= maxLen; i++) {
      total += Math.pow(charsetLength, i);
    }
    return total;
  };

  const formatEstimatedTime = (seconds: number) => {
    if (seconds < 60) {
      return `${seconds.toFixed(1)} seconds`;
    } else if (seconds < 3600) {
      return `${(seconds / 60).toFixed(1)} minutes`;
    } else if (seconds < 86400) {
      return `${(seconds / 3600).toFixed(1)} hours`;
    } else if (seconds < 31536000) {
      return `${(seconds / 86400).toFixed(1)} days`;
    } else {
      return `${(seconds / 31536000).toFixed(1)} years`;
    }
  };

  useEffect(() => {
    return () => {
      if (attackIntervalRef.current !== null) {
        clearInterval(attackIntervalRef.current);
      }
    };
  }, []);

  return (
    <DemoCard title="Brute Force Attack Simulation">
      <div className="mb-6">
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          This simulation demonstrates how a brute force attack works by trying all possible 
          character combinations until the correct password is found.
        </p>
        
        <InfoBox type="warning" icon={<AlertTriangle size={16} />}>
          For demonstration purposes, this simulation is limited and much faster than 
          real-world attacks. Actual brute force attacks can take significantly longer,
          especially against secure hash algorithms like bcrypt.
        </InfoBox>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="font-medium text-lg mb-4">Target Password Setup</h3>
          
          <InputField
            label="Password to Crack"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter a password"
            maxLength={10}
            disabled={isAttacking}
          />
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Hash Algorithm
            </label>
            <select
              value={hashType}
              onChange={(e) => setHashType(e.target.value)}
              className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
              disabled={isAttacking}
            >
              <option value="md5">MD5 (Fast, Insecure)</option>
              <option value="sha256">SHA-256 (No Salt)</option>
              <option value="bcrypt">Bcrypt (Slow, Secure)</option>
            </select>
          </div>
          
          <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-md mb-4">
            <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">Generated Hash:</div>
            <div className="font-mono text-xs break-all">{hashValue}</div>
          </div>
        </div>
        
        <div>
          <h3 className="font-medium text-lg mb-4">Attack Parameters</h3>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Character Set
            </label>
            <select
              value={charsetType}
              onChange={(e) => setCharsetType(e.target.value)}
              className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
              disabled={isAttacking}
            >
              <option value="lowercase">Lowercase Letters (26 chars)</option>
              <option value="alphanumeric">Alphanumeric Lowercase (36 chars)</option>
              <option value="full">Full Alphanumeric (62 chars)</option>
            </select>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Maximum Password Length: {maxLength}
            </label>
            <input
              type="range"
              min="1"
              max="8"
              value={maxLength}
              onChange={(e) => setMaxLength(parseInt(e.target.value))}
              className="w-full"
              disabled={isAttacking}
            />
            <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Note: Higher values exponentially increase attack time
            </div>
          </div>
          
          <div className="flex space-x-3">
            <Button 
              onClick={startAttack} 
              disabled={isAttacking}
              color="blue"
              icon={<Play size={16} />}
            >
              Start Attack
            </Button>
            
            <Button 
              onClick={stopAttack} 
              disabled={!isAttacking}
              color="red"
            >
              Stop Attack
            </Button>
          </div>
        </div>
      </div>
      
      <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
        <h3 className="font-medium text-lg mb-4">Attack Progress</h3>
        
        <ProgressBar value={progress} />
        
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-md">
            <div className="flex items-center text-gray-700 dark:text-gray-300 mb-1">
              <History size={16} className="mr-2" />
              <span className="text-sm font-medium">Attempts</span>
            </div>
            <div className="text-2xl font-semibold">{attempts.toLocaleString()}</div>
          </div>
          
          <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-md">
            <div className="flex items-center text-gray-700 dark:text-gray-300 mb-1">
              <Timer size={16} className="mr-2" />
              <span className="text-sm font-medium">Time Elapsed</span>
            </div>
            <div className="text-2xl font-semibold">{timeTaken.toFixed(2)}s</div>
          </div>
          
          <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-md">
            <div className="flex items-center text-gray-700 dark:text-gray-300 mb-1">
              <span className="text-sm font-medium">Attempts/Second</span>
            </div>
            <div className="text-2xl font-semibold">
              {timeTaken > 0 ? Math.round(attempts / timeTaken).toLocaleString() : 0}
            </div>
          </div>
        </div>
        
        {result && (
          <div className={`mt-6 p-4 rounded-md ${result.found ? 'bg-green-100 dark:bg-green-900' : 'bg-red-100 dark:bg-red-900'}`}>
            {result.found ? (
              <div>
                <h4 className="font-medium text-green-800 dark:text-green-300 mb-1">Password Cracked!</h4>
                <p className="text-green-700 dark:text-green-200">
                  Found password: <span className="font-mono font-bold">{result.password}</span> in {attempts.toLocaleString()} attempts
                </p>
              </div>
            ) : (
              <div>
                <h4 className="font-medium text-red-800 dark:text-red-300 mb-1">Attack Stopped</h4>
                <p className="text-red-700 dark:text-red-200">
                  Password not found after {attempts.toLocaleString()} attempts
                </p>
                {estimatedTime && (
                  <p className="text-red-700 dark:text-red-200 mt-1">
                    At this rate, a full attack would take approximately: <span className="font-bold">{estimatedTime}</span>
                  </p>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </DemoCard>
  );
};

export default BruteForceDemo;