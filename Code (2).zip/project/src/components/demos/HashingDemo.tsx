import React, { useState, useEffect } from 'react';
import { AlertTriangle, Check, Copy, Info } from 'lucide-react';
import DemoCard from '../ui/DemoCard';
import InputField from '../ui/InputField';
import { generateHash } from '../../utils/hashUtils';
import InfoBox from '../ui/InfoBox';

const HashingDemo = () => {
  const [password, setPassword] = useState('MySecureP@ss123');
  const [hashes, setHashes] = useState<Record<string, any>>({});
  const [copied, setCopied] = useState<string | null>(null);

  const hashTypes = [
    { 
      id: 'plain', 
      name: 'Plain Text', 
      description: 'Stores the password as-is with no protection.',
      security: 'extremely-insecure',
      warning: 'This method provides NO security and should never be used!'
    },
    { 
      id: 'md5', 
      name: 'MD5', 
      description: 'A fast hash function that is cryptographically broken.',
      security: 'insecure',
      warning: 'MD5 is considered broken and should not be used for passwords!'
    },
    { 
      id: 'sha256', 
      name: 'SHA-256', 
      description: 'A general-purpose cryptographic hash function.',
      security: 'weak-without-salt',
      warning: 'While stronger than MD5, using SHA-256 without salt is still vulnerable to rainbow table attacks!'
    },
    { 
      id: 'sha256-salted', 
      name: 'SHA-256 (With Salt)', 
      description: 'SHA-256 with a random salt added to prevent rainbow table attacks.',
      security: 'better',
      info: 'Adding a salt helps prevent rainbow table attacks, but modern password hashing should use specialized algorithms.'
    },
    { 
      id: 'bcrypt', 
      name: 'Bcrypt', 
      description: 'A password-hashing function designed to be slow and resistant to attacks.',
      security: 'secure',
      info: 'Bcrypt is designed specifically for password hashing and includes salt automatically. It\'s also computationally expensive by design, which slows down brute force attacks.'
    },
    { 
      id: 'pbkdf2', 
      name: 'PBKDF2', 
      description: 'Password-Based Key Derivation Function with customizable iterations.',
      security: 'secure',
      info: 'PBKDF2 is another good option that uses multiple iterations of a hash function.'
    }
  ];

  useEffect(() => {
    const updateHashes = async () => {
      const results: Record<string, any> = {};
      
      for (const type of hashTypes) {
        results[type.id] = await generateHash(password, type.id);
      }
      
      setHashes(results);
    };
    
    updateHashes();
  }, [password]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const getSecurityBadge = (security: string) => {
    switch (security) {
      case 'extremely-insecure':
        return <span className="bg-red-600 text-white text-xs px-2 py-1 rounded-full">Extremely Insecure</span>;
      case 'insecure':
        return <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">Insecure</span>;
      case 'weak-without-salt':
        return <span className="bg-orange-500 text-white text-xs px-2 py-1 rounded-full">Weak Without Salt</span>;
      case 'better':
        return <span className="bg-yellow-500 text-white text-xs px-2 py-1 rounded-full">Better</span>;
      case 'secure':
        return <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">Secure</span>;
      default:
        return null;
    }
  };

  return (
    <DemoCard title="Password Hashing Methods">
      <div className="mb-6">
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          This demonstration shows how different hashing algorithms store your password. 
          Enter a password below to see how it's transformed with various methods.
        </p>
        
        <InputField
          label="Password to Hash"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter a password"
        />
      </div>
      
      <div className="space-y-6">
        {hashTypes.map((type) => (
          <div 
            key={type.id}
            className="p-4 border rounded-lg bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
          >
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-medium text-lg">{type.name}</h3>
              {getSecurityBadge(type.security)}
            </div>
            
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{type.description}</p>
            
            <div className="bg-gray-100 dark:bg-gray-900 p-3 rounded-md font-mono text-sm overflow-x-auto mb-3">
              <div className="flex justify-between items-center">
                <span className="break-all pr-8">
                  {hashes[type.id]?.hash || 'Generating...'}
                </span>
                <button 
                  onClick={() => copyToClipboard(hashes[type.id]?.hash || '', type.id)}
                  className="ml-2 p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                  title="Copy to clipboard"
                >
                  {copied === type.id ? <Check size={16} /> : <Copy size={16} />}
                </button>
              </div>
            </div>
            
            {hashes[type.id]?.salt && (
              <div className="mb-3">
                <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">Salt:</div>
                <div className="bg-gray-100 dark:bg-gray-900 p-2 rounded-md font-mono text-xs overflow-x-auto">
                  {hashes[type.id].salt}
                </div>
              </div>
            )}
            
            {type.warning && (
              <InfoBox type="warning" icon={<AlertTriangle size={16} />}>
                {type.warning}
              </InfoBox>
            )}
            
            {type.info && (
              <InfoBox type="info" icon={<Info size={16} />}>
                {type.info}
              </InfoBox>
            )}
          </div>
        ))}
      </div>
    </DemoCard>
  );
};

export default HashingDemo;