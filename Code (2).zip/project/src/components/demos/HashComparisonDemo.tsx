import React, { useState, useEffect } from 'react';
import DemoCard from '../ui/DemoCard';
import InputField from '../ui/InputField';
import { ClockIcon, BarChart2, Timer } from 'lucide-react';
import { measureHashingPerformance } from '../../utils/hashUtils';
import InfoBox from '../ui/InfoBox';

const HashComparisonDemo = () => {
  const [password, setPassword] = useState('MySecureP@ss123');
  const [results, setResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const runPerformanceTest = async () => {
    setIsLoading(true);
    
    // Define algorithms to test
    const algorithms = [
      { id: 'md5', name: 'Simple MD5', options: {} },
      { id: 'sha256', name: 'Simple SHA-256', options: {} },
      { id: 'sha256-salted', name: 'Salted SHA-256', options: {} },
      { id: 'bcrypt', name: 'Bcrypt (8 rounds)', options: { rounds: 8 } },
      { id: 'bcrypt', name: 'Bcrypt (12 rounds)', options: { rounds: 12 } },
      { id: 'pbkdf2', name: 'PBKDF2 (10,000 rounds)', options: { rounds: 10000 } },
      { id: 'pbkdf2', name: 'PBKDF2 (100,000 rounds)', options: { rounds: 100000 } }
    ];
    
    const testResults = await measureHashingPerformance(password, algorithms);
    setResults(testResults);
    setIsLoading(false);
  };

  useEffect(() => {
    runPerformanceTest();
  }, []);

  // Find the fastest algorithm (highest ops/sec) to calculate relative speed
  const findMaxOpsPerSecond = () => {
    if (results.length === 0) return 1;
    return Math.max(...results.map(r => r.opsPerSecond));
  };

  const maxOpsPerSecond = findMaxOpsPerSecond();

  const getBarColor = (algorithm: string) => {
    if (algorithm.includes('MD5')) return 'bg-red-500';
    if (algorithm.includes('SHA-256') && !algorithm.includes('Salted')) return 'bg-orange-500';
    if (algorithm.includes('Salted SHA-256')) return 'bg-yellow-500';
    if (algorithm.includes('Bcrypt')) return 'bg-green-500';
    if (algorithm.includes('PBKDF2')) return 'bg-blue-500';
    return 'bg-gray-500';
  };

  const getSecurityLevel = (algorithm: string) => {
    if (algorithm.includes('MD5')) {
      return <span className="text-red-600 dark:text-red-400 text-xs">Insecure</span>;
    }
    if (algorithm.includes('SHA-256') && !algorithm.includes('Salted')) {
      return <span className="text-orange-600 dark:text-orange-400 text-xs">Weak without salt</span>;
    }
    if (algorithm.includes('Salted SHA-256')) {
      return <span className="text-yellow-600 dark:text-yellow-400 text-xs">Better</span>;
    }
    if (algorithm.includes('Bcrypt') || algorithm.includes('PBKDF2')) {
      return <span className="text-green-600 dark:text-green-400 text-xs">Secure</span>;
    }
    return null;
  };

  return (
    <DemoCard title="Hash Algorithm Performance Comparison">
      <div className="mb-6">
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          This demonstration compares the performance of different hashing algorithms.
          Slower hashing algorithms are actually better for password security because they
          make brute force attacks more time-consuming.
        </p>
        
        <InputField
          label="Test Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter a password"
        />
        
        <button
          onClick={runPerformanceTest}
          disabled={isLoading}
          className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Running Test...' : 'Run Performance Test'}
        </button>
      </div>
      
      <InfoBox type="info" icon={<Timer size={16} />}>
        Slower algorithms (like bcrypt with high rounds) are better for password security 
        because they slow down brute force attacks. A good password hash should be slow enough 
        to prevent brute force attacks but still fast enough for legitimate authentication.
      </InfoBox>
      
      <div className="mt-6">
        <div className="flex items-center mb-4">
          <BarChart2 size={20} className="mr-2 text-gray-700 dark:text-gray-300" />
          <h3 className="font-medium text-lg">Performance Results</h3>
        </div>
        
        {isLoading ? (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            Running performance tests...
          </div>
        ) : (
          <div className="space-y-4">
            {results.map((result, index) => (
              <div key={index} className="relative">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {result.name}
                    </span>
                    <span className="ml-2">{getSecurityLevel(result.name)}</span>
                  </div>
                  <div className="flex items-center">
                    <ClockIcon size={14} className="mr-1 text-gray-500 dark:text-gray-400" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {result.time.toFixed(6)} sec
                    </span>
                  </div>
                </div>
                <div className="h-6 w-full bg-gray-200 dark:bg-gray-700 rounded-md overflow-hidden">
                  <div
                    className={`h-full ${getBarColor(result.name)} transition-all duration-500`}
                    style={{ 
                      width: `${Math.max((result.opsPerSecond / maxOpsPerSecond) * 100, 1)}%` 
                    }}
                  >
                    <div className="h-full flex items-center px-2">
                      <span className="text-xs text-white font-medium">
                        {result.opsPerSecond.toFixed(1)} hashes/sec
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        {results.length > 0 && (
          <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
            <h4 className="font-medium text-blue-800 dark:text-blue-300 mb-2">Security Implications</h4>
            <ul className="text-sm text-blue-700 dark:text-blue-200 space-y-2">
              <li>• Faster algorithms (like MD5 and SHA-256) are much more vulnerable to brute force attacks</li>
              <li>• Modern password hashing algorithms are deliberately designed to be slow</li>
              <li>• Bcrypt and PBKDF2 have configurable "work factors" to adjust their speed</li>
              <li>• As computers get faster, work factors should be increased to maintain security</li>
              <li>• The ideal hash is slow enough to prevent attacks but fast enough for legitimate use</li>
            </ul>
          </div>
        )}
      </div>
    </DemoCard>
  );
};

export default HashComparisonDemo;