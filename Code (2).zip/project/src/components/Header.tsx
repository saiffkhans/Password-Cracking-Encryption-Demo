import React from 'react';
import { Shield, Lock, Zap } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-blue-900 text-white shadow-md">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-700 rounded-lg">
              <Shield className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Password Security Demo</h1>
              <p className="text-blue-200 text-sm">
                Hashing · Encryption · Attack Simulation
              </p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <Lock className="h-5 w-5 text-blue-300" />
              <span className="text-sm">Educational Purposes Only</span>
            </div>
            <div className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-yellow-300" />
              <span className="text-sm">Interactive Demos</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;