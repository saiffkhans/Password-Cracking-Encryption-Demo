import React, { useState } from 'react';
import DemoCard from './ui/DemoCard';
import { KeyRound, Shield, Lock, AlertTriangle, Database, Fingerprint } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

const ConceptsExplainer = () => {
  const [activeTab, setActiveTab] = useState('hashing');

  const tabs = [
    { id: 'hashing', label: 'Hashing', icon: <Fingerprint size={16} /> },
    { id: 'encryption', label: 'Encryption', icon: <Lock size={16} /> },
    { id: 'salting', label: 'Salting', icon: <Shield size={16} /> },
    { id: 'best-practices', label: 'Best Practices', icon: <KeyRound size={16} /> },
    { id: 'attacks', label: 'Attack Methods', icon: <AlertTriangle size={16} /> },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'hashing':
        return <HashingExplanation />;
      case 'encryption':
        return <EncryptionExplanation />;
      case 'salting':
        return <SaltingExplanation />;
      case 'best-practices':
        return <BestPracticesExplanation />;
      case 'attacks':
        return <AttackMethodsExplanation />;
      default:
        return <HashingExplanation />;
    }
  };

  return (
    <DemoCard title="Password Security Concepts">
      <div className="mb-6">
        <p className="text-gray-700 dark:text-gray-300">
          Understanding the fundamentals of password security is essential for implementing
          proper authentication systems. Explore the key concepts below.
        </p>
      </div>
      
      <div className="border-b border-gray-200 dark:border-gray-700 mb-6">
        <nav className="flex overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors flex items-center
                ${
                  activeTab === tab.id
                    ? 'border-blue-600 text-blue-600 dark:border-blue-500 dark:text-blue-500'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-700'
                }`}
              onClick={() => setActiveTab(tab.id)}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
      
      <div className="mb-6">
        {renderTabContent()}
      </div>
    </DemoCard>
  );
};

const HashingExplanation = () => {
  const hashExample = `import hashlib

# Simple SHA-256 hashing
def hash_password(password):
    # Convert the password string to bytes
    password_bytes = password.encode('utf-8')
    
    # Create a SHA-256 hash
    hash_object = hashlib.sha256(password_bytes)
    
    # Get the hexadecimal representation
    return hash_object.hexdigest()

# Example
password = "MySecurePassword"
hashed = hash_password(password)
print(f"Original: {password}")
print(f"Hashed: {hashed}")`;

  return (
    <div>
      <h3 className="text-xl font-medium mb-4 flex items-center">
        <Fingerprint className="mr-2" size={24} />
        Hashing
      </h3>
      
      <p className="mb-4">
        Hashing is a one-way function that converts input data (like a password) into a fixed-length
        string of characters. Unlike encryption, hashing is not reversible - you cannot derive the
        original input from the hash.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h4 className="font-medium mb-2">Key Characteristics</h4>
          <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
            <li>One-way process (cannot be reversed)</li>
            <li>Same input always produces the same output</li>
            <li>Even small changes in input produce completely different outputs</li>
            <li>Fixed output length regardless of input size</li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-medium mb-2">Common Algorithms</h4>
          <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
            <li><span className="text-red-500 dark:text-red-400">MD5</span> - Fast but insecure, should not be used</li>
            <li><span className="text-yellow-500 dark:text-yellow-400">SHA-256</span> - Secure for general use, but needs salt for passwords</li>
            <li><span className="text-green-500 dark:text-green-400">bcrypt</span> - Designed specifically for passwords with built-in salt</li>
            <li><span className="text-green-500 dark:text-green-400">PBKDF2</span> - Password-Based Key Derivation Function with iterations</li>
            <li><span className="text-green-500 dark:text-green-400">Argon2</span> - Modern algorithm resistant to specialized attacks</li>
          </ul>
        </div>
      </div>
      
      <div className="mb-6">
        <h4 className="font-medium mb-2">Example Code</h4>
        <SyntaxHighlighter language="python" style={vscDarkPlus} className="rounded-md">
          {hashExample}
        </SyntaxHighlighter>
      </div>
      
      <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
        <h4 className="font-medium text-blue-800 dark:text-blue-300 mb-2">Why Use Hashing for Passwords?</h4>
        <p className="text-blue-700 dark:text-blue-200">
          Hashing is ideal for password storage because you never need to retrieve the original
          password - you only need to verify that a user-provided password matches the stored hash.
          This way, even if your database is compromised, attackers cannot easily determine the
          actual passwords.
        </p>
      </div>
    </div>
  );
};

const EncryptionExplanation = () => {
  const encryptionExample = `from cryptography.fernet import Fernet

# Generate a key for encryption
def generate_key():
    return Fernet.generate_key()

# Encrypt a message
def encrypt_message(message, key):
    f = Fernet(key)
    encrypted = f.encrypt(message.encode())
    return encrypted

# Decrypt a message
def decrypt_message(encrypted, key):
    f = Fernet(key)
    decrypted = f.decrypt(encrypted)
    return decrypted.decode()

# Example
key = generate_key()
message = "Sensitive data"
encrypted = encrypt_message(message, key)
decrypted = decrypt_message(encrypted, key)

print(f"Original: {message}")
print(f"Encrypted: {encrypted}")
print(f"Decrypted: {decrypted}")`;

  return (
    <div>
      <h3 className="text-xl font-medium mb-4 flex items-center">
        <Lock className="mr-2" size={24} />
        Encryption
      </h3>
      
      <p className="mb-4">
        Encryption is a two-way function that converts data into a different format using a key.
        Unlike hashing, encryption is designed to be reversible, allowing the original data to be
        recovered with the correct decryption key.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h4 className="font-medium mb-2">Key Characteristics</h4>
          <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
            <li>Two-way process (can be reversed with the right key)</li>
            <li>Requires a secret key for both encryption and decryption</li>
            <li>Designed to protect data that needs to be retrieved later</li>
            <li>Output size varies based on the algorithm and input</li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-medium mb-2">Common Algorithms</h4>
          <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
            <li><span className="text-green-500 dark:text-green-400">AES</span> - Advanced Encryption Standard, widely used</li>
            <li><span className="text-green-500 dark:text-green-400">RSA</span> - Public-key encryption for asymmetric encryption</li>
            <li><span className="text-red-500 dark:text-red-400">DES</span> - Data Encryption Standard, outdated and insecure</li>
            <li><span className="text-green-500 dark:text-green-400">ChaCha20</span> - Modern stream cipher, good performance</li>
          </ul>
        </div>
      </div>
      
      <div className="mb-6">
        <h4 className="font-medium mb-2">Example Code</h4>
        <SyntaxHighlighter language="python" style={vscDarkPlus} className="rounded-md">
          {encryptionExample}
        </SyntaxHighlighter>
      </div>
      
      <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
        <h4 className="font-medium text-blue-800 dark:text-blue-300 mb-2">Why Not Use Encryption for Passwords?</h4>
        <p className="text-blue-700 dark:text-blue-200">
          While encryption is essential for protecting sensitive data that needs to be retrieved
          (like personal information, messages, etc.), it's not appropriate for password storage.
          If encrypted passwords are compromised along with the encryption key, all passwords become
          immediately accessible. There's also rarely a legitimate reason to access the original
          password - authentication only requires verification.
        </p>
      </div>
    </div>
  );
};

const SaltingExplanation = () => {
  const saltingExample = `import hashlib
import os

# Salted hashing
def hash_password_with_salt(password):
    # Generate a random salt
    salt = os.urandom(32)  # 32 bytes = 256 bits
    
    # Combine password and salt then hash
    password_bytes = password.encode('utf-8')
    hash_obj = hashlib.sha256(salt + password_bytes)
    password_hash = hash_obj.hexdigest()
    
    # Return both the salt and the hash
    return {
        'hash': password_hash,
        'salt': salt.hex()  # Convert to hex for storage
    }

# Verify a salted password
def verify_password(stored_hash, stored_salt, provided_password):
    # Convert stored salt from hex back to bytes
    salt = bytes.fromhex(stored_salt)
    
    # Hash the provided password with the stored salt
    password_bytes = provided_password.encode('utf-8')
    hash_obj = hashlib.sha256(salt + password_bytes)
    calculated_hash = hash_obj.hexdigest()
    
    # Compare the calculated hash with the stored hash
    return calculated_hash == stored_hash

# Example
password = "MySecurePassword"
stored = hash_password_with_salt(password)
print(f"Hash: {stored['hash']}")
print(f"Salt: {stored['salt']}")

# Verification
is_match = verify_password(stored['hash'], stored['salt'], password)
print(f"Password verified: {is_match}")`;

  return (
    <div>
      <h3 className="text-xl font-medium mb-4 flex items-center">
        <Shield className="mr-2" size={24} />
        Salting
      </h3>
      
      <p className="mb-4">
        Salting is a technique where random data (a "salt") is added to the input before hashing.
        Each user's password should have a unique salt, which is stored alongside the hash.
        This prevents various attacks, particularly rainbow table attacks.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h4 className="font-medium mb-2">Key Benefits</h4>
          <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
            <li>Prevents rainbow table attacks</li>
            <li>Ensures identical passwords don't result in identical hashes</li>
            <li>Adds an additional layer of security to hash functions</li>
            <li>Makes pre-computation attacks infeasible</li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-medium mb-2">Important Considerations</h4>
          <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
            <li>Salts should be unique for each user</li>
            <li>Salts don't need to be secret - they're stored with the hash</li>
            <li>Salts should be sufficiently long (at least 16 bytes)</li>
            <li>Modern hashing algorithms like bcrypt handle salting automatically</li>
          </ul>
        </div>
      </div>
      
      <div className="mb-6">
        <h4 className="font-medium mb-2">Example Code</h4>
        <SyntaxHighlighter language="python" style={vscDarkPlus} className="rounded-md">
          {saltingExample}
        </SyntaxHighlighter>
      </div>
      
      <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
        <h4 className="font-medium text-blue-800 dark:text-blue-300 mb-2">How Salting Defeats Rainbow Tables</h4>
        <p className="text-blue-700 dark:text-blue-200 mb-2">
          Rainbow tables are pre-computed tables of hash values for common passwords. They allow
          attackers to quickly look up a password given its hash.
        </p>
        <p className="text-blue-700 dark:text-blue-200">
          Salting defeats this by ensuring that even if two users have the same password, their
          hashes will be completely different due to different salts. An attacker would need to
          generate a new rainbow table for each unique salt, which is computationally infeasible.
        </p>
      </div>
    </div>
  );
};

const BestPracticesExplanation = () => {
  const bcryptExample = `import bcrypt

# Hash a password with bcrypt
def hash_password(password):
    # Convert password to bytes
    password_bytes = password.encode('utf-8')
    
    # Generate a salt with work factor 12
    salt = bcrypt.gensalt(rounds=12)
    
    # Hash the password with the salt
    hashed = bcrypt.hashpw(password_bytes, salt)
    
    # Return the hash as a string
    return hashed.decode('utf-8')

# Verify a password against a hash
def verify_password(stored_hash, provided_password):
    # Convert inputs to bytes
    stored_hash_bytes = stored_hash.encode('utf-8')
    provided_password_bytes = provided_password.encode('utf-8')
    
    # bcrypt handles the salt extraction and comparison
    return bcrypt.checkpw(provided_password_bytes, stored_hash_bytes)

# Example
password = "MySecurePassword"
hashed_password = hash_password(password)
print(f"Hashed: {hashed_password}")

# Verification
is_match = verify_password(hashed_password, password)
print(f"Password verified: {is_match}")`;

  return (
    <div>
      <h3 className="text-xl font-medium mb-4 flex items-center">
        <KeyRound className="mr-2" size={24} />
        Best Practices for Password Security
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h4 className="font-medium mb-2">Password Storage</h4>
          <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
            <li>Use specialized password hashing algorithms (bcrypt, Argon2, PBKDF2)</li>
            <li>Always salt passwords (modern algorithms handle this automatically)</li>
            <li>Use sufficiently high work factors that balance security and performance</li>
            <li>Never store passwords in plain text or with simple hashing</li>
            <li>Increase work factors over time as computing power increases</li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-medium mb-2">Additional Security Measures</h4>
          <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
            <li>Implement multi-factor authentication (MFA)</li>
            <li>Enforce strong password policies</li>
            <li>Implement rate limiting to prevent brute force attacks</li>
            <li>Use secure password reset mechanisms</li>
            <li>Consider passwordless authentication options</li>
          </ul>
        </div>
      </div>
      
      <div className="mb-6">
        <h4 className="font-medium mb-2">Example: Using bcrypt (Recommended)</h4>
        <SyntaxHighlighter language="python" style={vscDarkPlus} className="rounded-md">
          {bcryptExample}
        </SyntaxHighlighter>
      </div>
      
      <div className="mb-6">
        <h4 className="font-medium mb-2">Choosing the Right Work Factor</h4>
        <p className="mb-2 text-gray-700 dark:text-gray-300">
          The work factor (or number of iterations) controls how computationally expensive the
          hashing process is. Higher values increase security but also increase computation time.
        </p>
        <ul className="list-disc pl-5 space-y-1 text-gray-700 dark:text-gray-300">
          <li>For bcrypt, a work factor of 10-12 is considered good as of 2023</li>
          <li>For PBKDF2, at least 310,000 iterations is recommended</li>
          <li>For Argon2, parameters depend on available memory and CPU</li>
          <li>The ideal hash should take about 250-500ms on your server hardware</li>
          <li>Regularly benchmark and increase work factors as hardware improves</li>
        </ul>
      </div>
      
      <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
        <h4 className="font-medium text-blue-800 dark:text-blue-300 mb-2">OWASP Recommendations</h4>
        <p className="text-blue-700 dark:text-blue-200">
          The Open Web Application Security Project (OWASP) recommends using modern, purpose-built
          password hashing functions with appropriate work factors. They specifically recommend
          Argon2id (winner of the Password Hashing Competition), PBKDF2, scrypt, or bcrypt over
          general-purpose hash functions like SHA-256, even when salted.
        </p>
      </div>
    </div>
  );
};

const AttackMethodsExplanation = () => {
  return (
    <div>
      <h3 className="text-xl font-medium mb-4 flex items-center">
        <AlertTriangle className="mr-2" size={24} />
        Common Password Attack Methods
      </h3>
      
      <div className="grid grid-cols-1 gap-6 mb-6">
        <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
          <h4 className="font-medium mb-2">Brute Force Attacks</h4>
          <p className="mb-2 text-gray-700 dark:text-gray-300">
            A brute force attack attempts every possible combination of characters until the correct
            password is found. This method is exhaustive but can be very time-consuming for longer passwords.
          </p>
          <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-md mb-2">
            <h5 className="text-sm font-medium mb-1">Defense Strategy</h5>
            <ul className="list-disc pl-5 text-sm space-y-1 text-gray-700 dark:text-gray-300">
              <li>Use computationally expensive hashing algorithms (bcrypt, Argon2)</li>
              <li>Implement account lockouts or increasing delays after failed attempts</li>
              <li>Enforce minimum password length requirements (at least 12 characters)</li>
            </ul>
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400">
            <span className="font-medium">Time to crack:</span> Depends on length and complexity.
            An 8-character password might take days, while a 12+ character password could take years
            or centuries.
          </div>
        </div>
        
        <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
          <h4 className="font-medium mb-2">Dictionary Attacks</h4>
          <p className="mb-2 text-gray-700 dark:text-gray-300">
            Dictionary attacks use lists of common passwords and words instead of trying every
            possible combination. This is much faster than brute force for commonly used passwords.
          </p>
          <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-md mb-2">
            <h5 className="text-sm font-medium mb-1">Defense Strategy</h5>
            <ul className="list-disc pl-5 text-sm space-y-1 text-gray-700 dark:text-gray-300">
              <li>Prohibit common passwords (maintain a blocklist)</li>
              <li>Require a mix of character types (uppercase, lowercase, numbers, symbols)</li>
              <li>Encourage the use of passphrases rather than single words</li>
            </ul>
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400">
            <span className="font-medium">Time to crack:</span> Seconds to minutes for passwords
            in common dictionaries. Much more effective than brute force for common passwords.
          </div>
        </div>
        
        <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
          <h4 className="font-medium mb-2">Rainbow Table Attacks</h4>
          <p className="mb-2 text-gray-700 dark:text-gray-300">
            Rainbow tables are precomputed tables that contain hash values for possible passwords.
            Instead of computing hashes on the fly, attackers can look up a hash and find the
            corresponding password quickly.
          </p>
          <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-md mb-2">
            <h5 className="text-sm font-medium mb-1">Defense Strategy</h5>
            <ul className="list-disc pl-5 text-sm space-y-1 text-gray-700 dark:text-gray-300">
              <li>Always use unique salts for each password</li>
              <li>Use modern hashing algorithms that incorporate salts automatically</li>
              <li>Use sufficiently long salts (16+ bytes) to make table generation infeasible</li>
            </ul>
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400">
            <span className="font-medium">Time to crack:</span> Nearly instant for unsalted hashes
            that exist in the table. Completely ineffective against properly salted hashes.
          </div>
        </div>
        
        <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
          <h4 className="font-medium mb-2">Credential Stuffing</h4>
          <p className="mb-2 text-gray-700 dark:text-gray-300">
            Credential stuffing uses username/password pairs obtained from breaches of other services.
            Since many users reuse passwords across sites, attackers try these credentials on multiple
            services.
          </p>
          <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-md mb-2">
            <h5 className="text-sm font-medium mb-1">Defense Strategy</h5>
            <ul className="list-disc pl-5 text-sm space-y-1 text-gray-700 dark:text-gray-300">
              <li>Implement multi-factor authentication</li>
              <li>Monitor for suspicious login patterns</li>
              <li>Check passwords against known breach databases (like "Have I Been Pwned")</li>
              <li>Educate users about the dangers of password reuse</li>
            </ul>
          </div>
          <div className="text-xs text-gray-600 dark:text-gray-400">
            <span className="font-medium">Time to crack:</span> Instant if credentials are reused.
            This attack doesn't even need to crack hashes, it simply tries known credentials.
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConceptsExplainer;