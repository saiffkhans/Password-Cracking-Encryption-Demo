import string
import re
import math

class PasswordStrengthAnalyzer:
    """
    A class that analyzes the strength of passwords.
    """
    
    @staticmethod
    def calculate_entropy(password):
        """
        Calculate the entropy of a password in bits.
        Entropy is a measure of password strength based on the character set used.
        
        Args:
            password: The password to analyze
            
        Returns:
            float: Entropy in bits
        """
        # Determine the character sets used
        has_lowercase = bool(re.search(r'[a-z]', password))
        has_uppercase = bool(re.search(r'[A-Z]', password))
        has_digits = bool(re.search(r'\d', password))
        has_symbols = bool(re.search(r'[^a-zA-Z0-9]', password))
        
        # Calculate the size of the character set
        charset_size = 0
        if has_lowercase:
            charset_size += 26
        if has_uppercase:
            charset_size += 26
        if has_digits:
            charset_size += 10
        if has_symbols:
            charset_size += 33  # Approximate number of common symbols
        
        # Calculate entropy (log2(charset_size) * password_length)
        if charset_size == 0:  # Empty password
            return 0
            
        entropy = math.log2(charset_size) * len(password)
        return entropy
    
    @staticmethod
    def check_common_patterns(password):
        """
        Check for common patterns that weaken passwords.
        
        Args:
            password: The password to analyze
            
        Returns:
            list: List of identified patterns
        """
        patterns = []
        
        # Check for sequential characters
        sequences = [
            string.ascii_lowercase,
            string.ascii_uppercase,
            string.digits,
            "qwertyuiop",
            "asdfghjkl",
            "zxcvbnm"
        ]
        
        for seq in sequences:
            for i in range(len(seq) - 2):
                if seq[i:i+3] in password:
                    patterns.append(f"Sequential characters: {seq[i:i+3]}")
                    break
        
        # Check for repeated characters
        for i in range(len(password) - 2):
            if password[i] == password[i+1] == password[i+2]:
                patterns.append(f"Repeated characters: {password[i] * 3}")
                break
        
        # Check for common years
        if re.search(r'19\d\d|20\d\d', password):
            patterns.append("Contains a year")
        
        # Check for keyboard patterns
        keyboard_patterns = [
            "qwerty", "asdfgh", "zxcvbn", "123456", "qazwsx"
        ]
        for pattern in keyboard_patterns:
            if pattern in password.lower():
                patterns.append(f"Keyboard pattern: {pattern}")
                break
                
        return patterns
    
    @staticmethod
    def analyze_password(password):
        """
        Provide a comprehensive analysis of password strength.
        
        Args:
            password: The password to analyze
            
        Returns:
            dict: Analysis results
        """
        # Calculate basic metrics
        length = len(password)
        entropy = PasswordStrengthAnalyzer.calculate_entropy(password)
        patterns = PasswordStrengthAnalyzer.check_common_patterns(password)
        
        # Character composition
        char_composition = {
            "lowercase": sum(1 for c in password if c in string.ascii_lowercase),
            "uppercase": sum(1 for c in password if c in string.ascii_uppercase),
            "digits": sum(1 for c in password if c in string.digits),
            "symbols": sum(1 for c in password if c not in string.ascii_letters + string.digits)
        }
        
        # Determine strength category
        if entropy < 28:
            strength = "Very Weak"
            crack_time_estimate = "Instant to a few seconds"
        elif entropy < 36:
            strength = "Weak"
            crack_time_estimate = "Minutes to hours"
        elif entropy < 60:
            strength = "Moderate"
            crack_time_estimate = "Days to weeks"
        elif entropy < 80:
            strength = "Strong"
            crack_time_estimate = "Years to decades"
        else:
            strength = "Very Strong"
            crack_time_estimate = "Centuries or more"
        
        # Adjust strength based on patterns
        if patterns and entropy < 70:
            # Decrease strength if patterns are found
            if strength == "Very Strong":
                strength = "Strong"
            elif strength == "Strong":
                strength = "Moderate"
            elif strength == "Moderate":
                strength = "Weak"
            elif strength == "Weak":
                strength = "Very Weak"
                
            # Adjust crack time estimate
            if crack_time_estimate == "Centuries or more":
                crack_time_estimate = "Years to decades"
            elif crack_time_estimate == "Years to decades":
                crack_time_estimate = "Weeks to months"
            elif crack_time_estimate == "Days to weeks":
                crack_time_estimate = "Hours to days"
            elif crack_time_estimate == "Minutes to hours":
                crack_time_estimate = "Seconds to minutes"
        
        # Improvement suggestions
        suggestions = []
        if length < 12:
            suggestions.append("Make your password longer (at least 12 characters)")
        if char_composition["lowercase"] == 0:
            suggestions.append("Add lowercase letters")
        if char_composition["uppercase"] == 0:
            suggestions.append("Add uppercase letters")
        if char_composition["digits"] == 0:
            suggestions.append("Add numbers")
        if char_composition["symbols"] == 0:
            suggestions.append("Add special characters")
        if patterns:
            suggestions.append("Avoid common patterns and sequences")
        
        return {
            "length": length,
            "entropy": entropy,
            "strength": strength,
            "character_composition": char_composition,
            "patterns_found": patterns,
            "estimated_crack_time": crack_time_estimate,
            "improvement_suggestions": suggestions
        }