import React, { useState } from 'react';
import Header from './components/Header';
import TabNavigation from './components/TabNavigation';
import HashingDemo from './components/demos/HashingDemo';
import BruteForceDemo from './components/demos/BruteForceDemo';
import DictionaryAttackDemo from './components/demos/DictionaryAttackDemo';
import PasswordStrengthDemo from './components/demos/PasswordStrengthDemo';
import HashComparisonDemo from './components/demos/HashComparisonDemo';
import ConceptsExplainer from './components/ConceptsExplainer';
import Footer from './components/Footer';

function App() {
  const [activeTab, setActiveTab] = useState('hashing');

  const tabs = [
    { id: 'hashing', label: 'Hashing Methods' },
    { id: 'bruteforce', label: 'Brute Force Attack' },
    { id: 'dictionary', label: 'Dictionary Attack' },
    { id: 'strength', label: 'Password Strength' },
    { id: 'comparison', label: 'Hash Comparison' },
    { id: 'concepts', label: 'Security Concepts' },
  ];

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'hashing':
        return <HashingDemo />;
      case 'bruteforce':
        return <BruteForceDemo />;
      case 'dictionary':
        return <DictionaryAttackDemo />;
      case 'strength':
        return <PasswordStrengthDemo />;
      case 'comparison':
        return <HashComparisonDemo />;
      case 'concepts':
        return <ConceptsExplainer />;
      default:
        return <HashingDemo />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <TabNavigation 
          tabs={tabs} 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
        
        <div className="mt-6">
          {renderActiveTab()}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default App;