import hashlib
import bcrypt
import os
from passlib.hash import pbkdf2_sha256

class HashingMethods:
    """
    A class that provides various password hashing methods.
    """
    
    @staticmethod
    def plain_text(password):
        """Store password in plain text (insecure, for demonstration only)"""
        return password
    
    @staticmethod
    def simple_md5(password):
        """Create an MD5 hash of the password (insecure, for demonstration only)"""
        return hashlib.md5(password.encode()).hexdigest()
    
    @staticmethod
    def simple_sha256(password):
        """Create a SHA-256 hash of the password (without salt)"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    @staticmethod
    def salted_sha256(password, salt=None):
        """Create a SHA-256 hash with a salt"""
        if salt is None:
            salt = os.urandom(32)  # 32 bytes = 256 bits
        
        # Combine password and salt, then hash
        hash_obj = hashlib.sha256(salt + password.encode())
        password_hash = hash_obj.hexdigest()
        
        return {
            'hash': password_hash,
            'salt': salt
        }
    
    @staticmethod
    def bcrypt_hash(password, rounds=12):
        """Create a bcrypt hash of the password"""
        # Generate a salt with the specified number of rounds
        salt = bcrypt.gensalt(rounds=rounds)
        
        # Hash the password with the salt
        password_hash = bcrypt.hashpw(password.encode(), salt)
        
        return password_hash.decode()
    
    @staticmethod
    def pbkdf2_hash(password, rounds=100000):
        """Create a PBKDF2 hash with SHA-256"""
        return pbkdf2_sha256.using(rounds=rounds).hash(password)


class HashVerification:
    """
    A class that provides methods to verify passwords against their hashes.
    """
    
    @staticmethod
    def verify_plain_text(stored_password, provided_password):
        """Verify a plain text password (insecure, for demonstration only)"""
        return stored_password == provided_password
    
    @staticmethod
    def verify_simple_hash(stored_hash, provided_password, hash_function):
        """Verify a password against a simple hash (MD5/SHA-256)"""
        provided_hash = hash_function(provided_password.encode()).hexdigest()
        return stored_hash == provided_hash
    
    @staticmethod
    def verify_salted_sha256(stored_hash, stored_salt, provided_password):
        """Verify a password against a salted SHA-256 hash"""
        hash_obj = hashlib.sha256(stored_salt + provided_password.encode())
        provided_hash = hash_obj.hexdigest()
        return stored_hash == provided_hash
    
    @staticmethod
    def verify_bcrypt(stored_hash, provided_password):
        """Verify a password against a bcrypt hash"""
        return bcrypt.checkpw(provided_password.encode(), stored_hash.encode())
    
    @staticmethod
    def verify_pbkdf2(stored_hash, provided_password):
        """Verify a password against a PBKDF2 hash"""
        return pbkdf2_sha256.verify(provided_password, stored_hash)