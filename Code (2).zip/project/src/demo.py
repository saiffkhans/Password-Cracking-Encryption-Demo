import time
import string
import random
import os
from colorama import Fore, Style, init
from tabulate import tabulate

# Import our modules
from hash_utils import HashingMethods
from attack_utils import BruteForceAttack, DictionaryAttack, PasswordGenerator
from password_strength import PasswordStrengthAnalyzer

# Initialize colorama
init(autoreset=True)

class PasswordDemo:
    """
    A class that demonstrates various password security concepts and attacks.
    """
    
    def __init__(self):
        self.hashing = HashingMethods()
    
    def generate_random_password(self, length=8, use_uppercase=True, use_digits=True, use_symbols=True):
        """Generate a random password of specified length and complexity"""
        chars = string.ascii_lowercase
        if use_uppercase:
            chars += string.ascii_uppercase
        if use_digits:
            chars += string.digits
        if use_symbols:
            chars += string.punctuation
            
        return ''.join(random.choice(chars) for _ in range(length))
    
    def print_header(self, text):
        """Print a formatted header"""
        print("\n" + "=" * 80)
        print(f"{Fore.CYAN}{Style.BRIGHT}{text}")
        print("=" * 80)
    
    def print_subheader(self, text):
        """Print a formatted subheader"""
        print(f"\n{Fore.YELLOW}{Style.BRIGHT}{text}")
        print("-" * 60)
    
    def print_success(self, text):
        """Print a success message"""
        print(f"{Fore.GREEN}{Style.BRIGHT}✓ {text}")
    
    def print_error(self, text):
        """Print an error message"""
        print(f"{Fore.RED}{Style.BRIGHT}✗ {text}")
    
    def print_info(self, text):
        """Print an info message"""
        print(f"{Fore.BLUE}{text}")
    
    def print_warning(self, text):
        """Print a warning message"""
        print(f"{Fore.YELLOW}{text}")
    
    def demonstrate_hashing_methods(self):
        """Demonstrate various password hashing methods"""
        self.print_header("DEMONSTRATION OF PASSWORD HASHING METHODS")
        
        # Sample password
        password = "MySecureP@ss123"
        self.print_info(f"Sample password: {password}")
        
        # Plain text (insecure)
        self.print_subheader("1. Plain Text (Extremely Insecure)")
        plain = self.hashing.plain_text(password)
        print(f"Stored as: {plain}")
        self.print_warning("⚠️ This method provides NO security and should never be used!")
        
        # MD5 (insecure)
        self.print_subheader("2. MD5 Hash (Insecure)")
        md5_hash = self.hashing.simple_md5(password)
        print(f"MD5 Hash: {md5_hash}")
        self.print_warning("⚠️ MD5 is considered broken and should not be used for passwords!")
        
        # SHA-256 (without salt)
        self.print_subheader("3. SHA-256 (Without Salt)")
        sha256_hash = self.hashing.simple_sha256(password)
        print(f"SHA-256 Hash: {sha256_hash}")
        self.print_warning("⚠️ While stronger than MD5, using SHA-256 without salt is still vulnerable to rainbow table attacks!")
        
        # SHA-256 (with salt)
        self.print_subheader("4. SHA-256 (With Salt)")
        salted_result = self.hashing.salted_sha256(password)
        print(f"Salt (hex): {salted_result['salt'].hex()}")
        print(f"Salted SHA-256 Hash: {salted_result['hash']}")
        self.print_info("✓ Adding a salt helps prevent rainbow table attacks, but modern password hashing should use specialized algorithms.")
        
        # Bcrypt
        self.print_subheader("5. Bcrypt (Modern, Secure)")
        bcrypt_hash = self.hashing.bcrypt_hash(password)
        print(f"Bcrypt Hash: {bcrypt_hash}")
        self.print_success("✓ Bcrypt is designed specifically for password hashing and includes salt automatically.")
        self.print_info("✓ It's also computationally expensive by design, which slows down brute force attacks.")
        
        # PBKDF2
        self.print_subheader("6. PBKDF2 (Modern, Secure)")
        pbkdf2_hash = self.hashing.pbkdf2_hash(password)
        print(f"PBKDF2 Hash: {pbkdf2_hash}")
        self.print_success("✓ PBKDF2 is another good option that uses multiple iterations of a hash function.")
        
        print("\n")
    
    def demonstrate_brute_force(self):
        """Demonstrate a brute force attack"""
        self.print_header("DEMONSTRATION OF BRUTE FORCE ATTACK")
        
        # Generate a simple password for demonstration
        password = "abc123"
        self.print_info(f"Target password (unknown to attacker): {password}")
        
        # Generate hashes
        sha256_hash = self.hashing.simple_sha256(password)
        self.print_info(f"SHA-256 hash: {sha256_hash}")
        
        bcrypt_hash = self.hashing.bcrypt_hash(password, rounds=8)  # Lower rounds for demo
        self.print_info(f"Bcrypt hash: {bcrypt_hash}")
        
        # Set up brute force attack parameters
        charset = string.ascii_lowercase + string.digits
        min_length = 3
        max_length = 6
        max_attempts = 50000  # Limit attempts for demonstration
        
        self.print_subheader("Attempting brute force attack on SHA-256 hash")
        print(f"Character set: {charset}")
        print(f"Password length range: {min_length}-{max_length}")
        print(f"Maximum attempts: {max_attempts}")
        
        # Brute force SHA-256
        bf_attack = BruteForceAttack(self.hashing.simple_sha256)
        start_time = time.time()
        result, attempts, time_taken = bf_attack.attack_hash(
            sha256_hash, charset, min_length, max_length, 
            max_attempts=max_attempts
        )
        
        if result:
            self.print_success(f"Password cracked: {result}")
            self.print_info(f"Attempts: {attempts:,}")
            self.print_info(f"Time taken: {time_taken:.4f} seconds")
        else:
            self.print_error("Failed to crack password within attempt limit")
            self.print_info(f"Attempts made: {attempts:,}")
        
        # Try with bcrypt (will be much slower)
        self.print_subheader("Attempting brute force attack on Bcrypt hash")
        print("Note: This will be MUCH slower due to bcrypt's design")
        print("Limiting to 100 attempts for demonstration...")
        
        # Use a simplified verify function for bcrypt
        def verify_bcrypt(stored_hash, password):
            import bcrypt
            return bcrypt.checkpw(password.encode(), stored_hash.encode())
        
        bf_attack = BruteForceAttack(None, verify_bcrypt)
        start_time = time.time()
        result, attempts, time_taken = bf_attack.attack_hash(
            bcrypt_hash, charset, min_length, max_length, 
            max_attempts=100  # Very limited for bcrypt demo
        )
        
        if result:
            self.print_success(f"Password cracked: {result}")
            self.print_info(f"Attempts: {attempts:,}")
            self.print_info(f"Time taken: {time_taken:.4f} seconds")
        else:
            self.print_warning("Failed to crack bcrypt password within attempt limit")
            self.print_info(f"Attempts made: {attempts:,}")
            self.print_info(f"Time taken: {time_taken:.4f} seconds")
            self.print_info(f"Average time per attempt: {time_taken/attempts:.4f} seconds")
            
            # Calculate how long it would actually take
            total_combinations = sum(len(charset) ** length for length in range(min_length, max_length + 1))
            estimated_time = (time_taken/attempts) * total_combinations
            
            self.print_warning(f"At this rate, cracking would take approximately:")
            if estimated_time < 60:
                self.print_warning(f"  {estimated_time:.1f} seconds")
            elif estimated_time < 3600:
                self.print_warning(f"  {estimated_time/60:.1f} minutes")
            elif estimated_time < 86400:
                self.print_warning(f"  {estimated_time/3600:.1f} hours")
            elif estimated_time < 31536000:
                self.print_warning(f"  {estimated_time/86400:.1f} days")
            else:
                self.print_warning(f"  {estimated_time/31536000:.1f} years")
        
        print("\n")
    
    def demonstrate_dictionary_attack(self):
        """Demonstrate a dictionary attack"""
        self.print_header("DEMONSTRATION OF DICTIONARY ATTACK")
        
        # Use a common password for the demonstration
        password = "password123"
        self.print_info(f"Target password (unknown to attacker): {password}")
        
        # Generate hashes
        sha256_hash = self.hashing.simple_sha256(password)
        self.print_info(f"SHA-256 hash: {sha256_hash}")
        
        bcrypt_hash = self.hashing.bcrypt_hash(password, rounds=8)  # Lower rounds for demo
        self.print_info(f"Bcrypt hash: {bcrypt_hash}")
        
        # Dictionary attack on SHA-256
        self.print_subheader("Attempting dictionary attack on SHA-256 hash")
        dict_attack = DictionaryAttack(self.hashing.simple_sha256)
        result, attempts, time_taken = dict_attack.attack_hash(
            sha256_hash, apply_common_transforms=True
        )
        
        if result:
            self.print_success(f"Password cracked: {result}")
            self.print_info(f"Attempts: {attempts:,}")
            self.print_info(f"Time taken: {time_taken:.4f} seconds")
        else:
            self.print_error("Failed to crack password with dictionary attack")
            self.print_info(f"Attempts made: {attempts:,}")
        
        # Try with bcrypt (limited attempts)
        self.print_subheader("Attempting dictionary attack on Bcrypt hash")
        print("Note: This will be slower due to bcrypt's design")
        print("Limiting to 20 attempts for demonstration...")
        
        # Use a simplified verify function for bcrypt
        def verify_bcrypt(stored_hash, password):
            import bcrypt
            return bcrypt.checkpw(password.encode(), stored_hash.encode())
        
        # Create a small dictionary for the demo
        mini_dict = ["password", "123456", "qwerty", "password123", "admin"]
        
        dict_attack = DictionaryAttack(None, verify_bcrypt)
        result, attempts, time_taken = dict_attack.attack_hash(
            bcrypt_hash, dictionary=mini_dict
        )
        
        if result:
            self.print_success(f"Password cracked: {result}")
            self.print_info(f"Attempts: {attempts:,}")
            self.print_info(f"Time taken: {time_taken:.4f} seconds")
        else:
            self.print_error("Failed to crack bcrypt password with limited dictionary")
            self.print_info(f"Attempts made: {attempts:,}")
        
        print("\n")
    
    def demonstrate_password_strength(self):
        """Demonstrate password strength analysis"""
        self.print_header("PASSWORD STRENGTH ANALYSIS")
        
        passwords = [
            "password",
            "Password1",
            "P@ssw0rd",
            "CorrectHorseBatteryStaple",
            "xT5!9pQ#2mLz@7"
        ]
        
        analyzer = PasswordStrengthAnalyzer()
        
        for password in passwords:
            self.print_subheader(f"Analyzing: {password}")
            analysis = analyzer.analyze_password(password)
            
            # Color-code the strength
            if analysis["strength"] == "Very Weak":
                strength_colored = f"{Fore.RED}{Style.BRIGHT}{analysis['strength']}"
            elif analysis["strength"] == "Weak":
                strength_colored = f"{Fore.RED}{analysis['strength']}"
            elif analysis["strength"] == "Moderate":
                strength_colored = f"{Fore.YELLOW}{analysis['strength']}"
            elif analysis["strength"] == "Strong":
                strength_colored = f"{Fore.GREEN}{analysis['strength']}"
            else:
                strength_colored = f"{Fore.GREEN}{Style.BRIGHT}{analysis['strength']}"
            
            # Display analysis
            print(f"Length: {analysis['length']} characters")
            print(f"Entropy: {analysis['entropy']:.2f} bits")
            print(f"Strength: {strength_colored}")
            print(f"Estimated crack time: {analysis['estimated_crack_time']}")
            
            # Character composition
            comp = analysis["character_composition"]
            print("\nCharacter Composition:")
            composition_table = [
                ["Lowercase", comp["lowercase"], f"{comp['lowercase']/analysis['length']*100:.1f}%"],
                ["Uppercase", comp["uppercase"], f"{comp['uppercase']/analysis['length']*100:.1f}%"],
                ["Digits", comp["digits"], f"{comp['digits']/analysis['length']*100:.1f}%"],
                ["Symbols", comp["symbols"], f"{comp['symbols']/analysis['length']*100:.1f}%"]
            ]
            print(tabulate(composition_table, headers=["Type", "Count", "Percentage"]))
            
            # Patterns found
            if analysis["patterns_found"]:
                print("\nPatterns Found:")
                for pattern in analysis["patterns_found"]:
                    print(f"{Fore.YELLOW}⚠️ {pattern}")
            
            # Suggestions
            if analysis["improvement_suggestions"]:
                print("\nImprovement Suggestions:")
                for suggestion in analysis["improvement_suggestions"]:
                    print(f"{Fore.BLUE}→ {suggestion}")
            
            print()
    
    def demonstrate_hash_comparison(self):
        """Compare the time required to compute different hash types"""
        self.print_header("HASH ALGORITHM PERFORMANCE COMPARISON")
        
        password = "MySecureP@ss123"
        self.print_info(f"Test password: {password}")
        
        # Define algorithms to test
        algorithms = [
            ("Simple MD5", lambda p: self.hashing.simple_md5(p)),
            ("Simple SHA-256", lambda p: self.hashing.simple_sha256(p)),
            ("Salted SHA-256", lambda p: self.hashing.salted_sha256(p)),
            ("Bcrypt (8 rounds)", lambda p: self.hashing.bcrypt_hash(p, rounds=8)),
            ("Bcrypt (12 rounds)", lambda p: self.hashing.bcrypt_hash(p, rounds=12)),
            ("PBKDF2 (10,000 rounds)", lambda p: self.hashing.pbkdf2_hash(p, rounds=10000)),
            ("PBKDF2 (100,000 rounds)", lambda p: self.hashing.pbkdf2_hash(p, rounds=100000))
        ]
        
        # Run tests
        results = []
        
        for name, func in algorithms:
            # Time the algorithm
            start_time = time.time()
            func(password)
            end_time = time.time()
            time_taken = end_time - start_time
            
            # Calculate operations per second (for comparison)
            ops_per_second = 1 / time_taken
            
            results.append({
                "name": name,
                "time": time_taken,
                "ops_per_second": ops_per_second
            })
        
        # Display results in a table
        table_data = []
        for r in results:
            table_data.append([
                r["name"],
                f"{r['time']:.6f} sec",
                f"{r['ops_per_second']:.1f}"
            ])
        
        print(tabulate(
            table_data,
            headers=["Algorithm", "Time per Hash", "Hashes per Second"],
            tablefmt="grid"
        ))
        
        self.print_info("\nSecurity Implication:")
        self.print_info("Slower hashing algorithms (like bcrypt with high rounds) are actually")
        self.print_info("BETTER for password security because they slow down brute force attacks.")
        self.print_success("A good password hash should be slow enough to prevent brute force")
        self.print_success("but still fast enough for legitimate authentication.")
        
        print("\n")
    
    def run_all_demos(self):
        """Run all demonstrations"""
        self.print_header("PASSWORD SECURITY DEMONSTRATION")
        print("This program demonstrates various password security concepts including:")
        print("  • Different hashing algorithms and their properties")
        print("  • The importance of salting passwords")
        print("  • Brute force attack simulation")
        print("  • Dictionary attack simulation")
        print("  • Password strength analysis")
        print("  • Performance comparison of hashing algorithms")
        
        input("\nPress Enter to begin...")
        
        self.demonstrate_hashing_methods()
        input("\nPress Enter to continue to brute force demonstration...")
        
        self.demonstrate_brute_force()
        input("\nPress Enter to continue to dictionary attack demonstration...")
        
        self.demonstrate_dictionary_attack()
        input("\nPress Enter to continue to password strength analysis...")
        
        self.demonstrate_password_strength()
        input("\nPress Enter to continue to hash algorithm comparison...")
        
        self.demonstrate_hash_comparison()
        
        self.print_header("DEMONSTRATION COMPLETE")
        print("Thank you for exploring password security concepts!")
        print("Remember the key takeaways:")
        print("  1. Always use a strong, modern hashing algorithm (bcrypt, Argon2, PBKDF2)")
        print("  2. Ensure passwords are properly salted")
        print("  3. Encourage users to create strong, unique passwords")
        print("  4. Consider implementing multi-factor authentication for additional security")


if __name__ == "__main__":
    demo = PasswordDemo()
    demo.run_all_demos()